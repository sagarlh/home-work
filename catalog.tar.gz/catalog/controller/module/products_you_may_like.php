<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class ControllerModuleProductsYouMayLike extends Controller {

    public function index() {
        $this->load->language('module/seller_upload_items');
        $product_id = $this->request->get['product_id'];
        $this->load->model('catalog/product');
        $products = $this->model_catalog_product->getYouMayLikeProducts($product_id);
        $this->load->model('tool/image');
        $data['products'] = array();
        if (count($products) > 0) {
            foreach ($products as $product) {

                if (file_exists(DIR_IMAGE . $product['image'])) {
                    // echo DIR_IMAGE.$product['image']."<br/>";
                    $thumb = $this->model_tool_image->resize($product['image'], 250, 250);
                } else {
                    $thumb = 'image/no_image_product.gif';
                }
                $data['products'][] = array(
                    'id' => $product['product_id'],
                    'price' => number_format($product['price'], 2),
                    'image' => $thumb,
                    'link' => $this->url->link('product/product', 'product_id='.$product['product_id'], 'SSL')
                );
            }
        }
        if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/module/products_you_may_like.tpl')) {

            return $this->load->view($this->config->get('config_template') . '/template/module/products_you_may_like.tpl', $data);
        } else {
            return $this->load->view('default/template/module/seller_upload_items.tpl', $data);
        }
    }

}
