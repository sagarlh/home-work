<?php
// Text
$_['text_total_shipping']		= 'Shipping';
$_['text_total_discount']		= 'Discount';
$_['text_total_tax']			= 'Tax';
$_['text_total_sub']			= 'Sub-total';
$_['text_total']				= 'Total';
$_['text_smp_id']				= 'Selling Manager sale ID: ';
$_['text_buyer']				= 'Buyer username: ';