<?php
// Heading 
$_['heading_title']     = 'My Shipping Preference';

// Text
$_['text_shipping']       = 'Shipping Preference';
$_['text_account']       = 'Account';
$_['text_success']      = 'Success: Your shipping preference has been successfully updated.';

// Entry
$_['entry_pick']   = 'Pick Up';
$_['entry_delivery']   = 'Delivery';
$_['entry_seller']      = 'Seller Delivery Option';

// Error
$_['error_nooption']     = 'Warning: Please select your preference!';
?>