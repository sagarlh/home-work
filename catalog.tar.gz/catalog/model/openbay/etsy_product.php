<?php
class ModelOpenbayEtsyProduct extends Model {
	public function inbound($data) {

	}
}