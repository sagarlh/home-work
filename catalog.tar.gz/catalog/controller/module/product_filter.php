<?php
class ControllerModuleProductFilter extends Controller {
	public function index() {
		
		$this->load->model('catalog/product');
		
		$filter_groups = $this->model_catalog_product->getFilters();
		
		
		
		$filer_base_array=array();
		
		foreach($filter_groups as $arr){
			
			$filer_base_array[$arr['group_name']][]=array(
			   'filter_id'=>$arr['filter_id'],
			   'name'=>$arr['name'],
			   'filter_group_id'=>$arr['filter_group_id']
			);
			
		}
		$data['filer_base_array']=$filer_base_array;
		$data['current_route']=isset($this->request->get['route'])?$this->request->get['route']:'';
		$data['path']=isset($this->request->get['path'])?$this->request->get['path']:'';
		$data['top_id']=isset($this->request->get['top_id'])?$this->request->get['top_id']:'';
		$data['search']=isset($this->request->get['search'])?$this->request->get['search']:'';
		
		$data['filter']=isset($this->request->get['filter'])?explode(',',$this->request->get['filter']):0;
		$data['filter_cond']=isset($this->request->get['filter_cond'])?$this->request->get['filter_cond']:0;
		
		
		if(isset($this->request->get['fund']) && $this->request->get['fund']==1){
			$data['fund']=1;
		}else{
			$data['fund']=0;
		}
	
		
		//print_r($filer_base_array);
		
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/module/product_filter.tpl')) {
			//$this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/module/product_filter.tpl', $data));
			return $this->load->view($this->config->get('config_template') . '/template/module/product_filter.tpl', $data);
		} else {
			return $this->load->view('default/template/module/product_filter.tpl', $data);
			//$this->response->setOutput($this->load->view('default/template/module/product_filter.tpl', $data));
		}
		
	}
}