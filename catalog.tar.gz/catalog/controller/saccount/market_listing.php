<?php
class ControllerSaccountMarketListing extends Controller {  
	public function index() { 
		
		if (!$this->seller->isLogged()) {
	  		$this->response->redirect($this->url->link('common/home', '', 'SSL'));
    	}
		
		$this->language->load('saccount/subscribe');
		$this->document->setTitle($this->language->get('heading_title'));
		
		$data['breadcrumbs'] = array();

      	$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home'),     	
        	'separator' => false
      	); 

      	$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('text_account'),
			'href'      => $this->url->link('saccount/account', '', 'SSL')
      	);

      	$data['breadcrumbs'][] = array(
        	'text'      => "Market Listing",
			'href'      => $this->url->link('saccount/market_listing', '', 'SSL')
      	);
		
		
		
		$this->load->model('saccount/market_listing');
		$this->load->model('saccount/seller');
		
		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		$data1 = array(		
			'start'                  => ($page - 1) * 5,

			'limit'                  => 5

		);
		$data['listings'] = $this->model_saccount_market_listing->getAllListing($data1,$this->seller->getId());
		
		$total_list = $this->model_saccount_market_listing->getTotalListing($data1,$this->seller->getId());
		
		//echo $total_list;
		$url='';
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		
		
		
		//print_r($data);
		
		
		$data['back'] = $this->url->link('saccount/account', '', 'SSL');
		$data['logged'] = $this->seller->isLogged();
		$seller_info = $this->model_saccount_seller->getSeller($this->seller->getId());
		$data['folder_name'] = $seller_info['foldername'];
		$data['seller_id']= $this->seller->getId();
		
		

		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
		$data['seller_right'] = $this->load->controller('product/seller_right');
		$data['seller_profile'] = $this->load->controller('product/seller_profile');
		$data['seller_billboard'] = $this->load->controller('product/seller_billboard');
		$data['seller_marketplace'] = $this->load->controller('product/seller_marketplace');
		
			$pagination = new Pagination();
			$pagination->total = $total_list;
			$pagination->page = $page;
			$pagination->limit = 5;
			$pagination->text = $this->language->get('text_pagination');
			$pagination->url = $this->url->link('saccount/market_listing', 'page={page}', 'SSL');
		
			$data['pagination'] = $pagination->render();
		
		
		
		// $data['pagination'] = $pagination->render();
			
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/saccount/market_listing.tpl')) {
			$this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/saccount/market_listing.tpl', $data));
		} else {
			$this->response->setOutput($this->load->view('default/template/saccount/market_listing.tpl', $data));
		}	   
	}	
}
?>