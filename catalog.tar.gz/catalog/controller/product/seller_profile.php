<?php 
class ControllerProductSellerProfile extends Controller {  
	public function index() { 
		$this->language->load('product/seller');
		$this->load->model('catalog/seller');
		$this->load->model('catalog/funding');
		$this->load->model('catalog/product');
		$this->load->model('tool/image');
	
	    if( $this->request->get['route'] == 'product/seller' ){
			if($this->seller->isLogged() && $this->request->get['seller_id'] == $this->seller->getId() ){ $data['same_id'] = 1; } else { $data['same_id'] = 0; }
			$seller_id = $this->request->get['seller_id'];	
		}else{
			$data['same_id'] = 1;
			$seller_id = $this->seller->getId();	
		}
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'p.sort_order';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		
		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else { 
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_product_limit');
		}
  
		$data1 = array(
			'filter_seller_id' => $seller_id, 
			'sort'               => $sort,
			'order'              => $order,
			'start'              => ($page - 1) * $limit,
			'limit'              => $limit
		);
		   
		$product_total = $this->model_catalog_seller->getTotalProducts($data1,$seller_id); 
		$data['product_total']=$product_total;
		
		$seller_info = $this->model_catalog_seller->getSeller($seller_id);		
		
		$seller_market_info = $this->model_catalog_seller->getSellerMarket($seller_id);
			
		
		
		$data['logged'] = $this->seller->isLogged();
		$data['seller_id']= $seller_id;
        $data['name'] = html_entity_decode($seller_info['name'], ENT_QUOTES, 'UTF-8');
		if($this->seller->isLogged()){
			$data['seller_group_id'] =  $_GET['market_id'];
		} else {
			$data['seller_group_id'] = $_GET['market_id'];
		}
		
		if ($seller_info) {
		    if (!empty($seller_info) && $seller_info['image'] && file_exists(DIR_IMAGE . $seller_info['image'])) {
				//$data['thumb'] = $this->model_tool_image->resize($seller_info['image'], 300, 300);
				$data['thumb'] = HTTPS_SERVER . 'timthumb.php?src='.HTTPS_SERVER . 'image/' . $seller_info['image'].'&h=290&w=300';
				$data['image'] = $seller_info['image'];
			} else { 
				//$data['thumb'] = $this->model_tool_image->resize('no_image.png', 300, 300);
				//$data['image'] = 'no_image.png';
				if($data['seller_group_id']==1){
					//$data['thumb'] = $this->model_tool_image->resize('no_image.png', 300, 300);
				$data['thumb'] = HTTPS_SERVER . 'timthumb.php?src='.HTTPS_SERVER . 'image/b58.jpg&h=290&w=300';
				$data['image'] = 'b58.jpg';
				}elseif($data['seller_group_id']==2){
					$data['thumb'] = HTTPS_SERVER . 'timthumb.php?src='.HTTPS_SERVER . 'image/fund profile.png&h=290&w=300';
					//$data['thumb'] = $this->model_tool_image->resize('no_image.png', 300, 300);
				$data['image'] = 'fund profile.png';
				}elseif($data['seller_group_id']==3)
				{
					$data['thumb'] = HTTPS_SERVER . 'timthumb.php?src='.HTTPS_SERVER . 'image/shutterstock_233733946.jpg&h=290&w=300';
					//$data['thumb'] = $this->model_tool_image->resize('no_image.png', 300, 300);
				$data['image'] = 'shutterstock_233733946.jpg';
				}
		    }
		} else {
			//$data['thumb'] = $this->model_tool_image->resize('no_image.png', 300, 300);
			//$data['image'] = 'no_image.png';
			if($data['seller_group_id']==1){
					//$data['thumb'] = $this->model_tool_image->resize('no_image.png', 300, 300);
				$data['thumb'] = HTTPS_SERVER . 'timthumb.php?src='.HTTPS_SERVER . 'image/b58.jpg&h=290&w=300';
				$data['image'] = 'b58.jpg';
				}elseif($data['seller_group_id']==2){
					$data['thumb'] = HTTPS_SERVER . 'timthumb.php?src='.HTTPS_SERVER . 'image/fund profile.png&h=290&w=300';
					//$data['thumb'] = $this->model_tool_image->resize('no_image.png', 300, 300);
				$data['image'] = 'fund profile.png';
				}elseif($data['seller_group_id']==3)
				{
					$data['thumb'] = HTTPS_SERVER . 'timthumb.php?src='.HTTPS_SERVER . 'image/shutterstock_233733946.jpg&h=290&w=300';
					//$data['thumb'] = $this->model_tool_image->resize('no_image.png', 300, 300);
				$data['image'] = 'shutterstock_233733946.jpg';
				}
		}
		
	   $raised = $this->model_catalog_funding->getRaised($seller_id);
		
		$data['amount_raised'] = $this->currency->format($raised);
		$data['target_amount'] = $this->currency->format($seller_info['fund_total']);
		
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/product/seller_profile.tpl')) {
			return $this->load->view($this->config->get('config_template') . '/template/product/seller_profile.tpl', $data);
		} else {
			return $this->load->view('default/template/product/seller_profile.tpl', $data);
		}
	   
	}	
}
?>