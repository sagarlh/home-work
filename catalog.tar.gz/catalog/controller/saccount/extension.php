<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');
include_once(DIR_SYSTEM.'library/FedexAPI.php');
class ControllerSaccountExtension extends Controller {

    private $error = array();

    public function index() {
        if (!$this->seller->isLogged()) {
            $this->session->data['redirect'] = $this->url->link('common/home', '', 'SSL');

            $this->response->redirect($this->url->link('common/home', '', 'SSL'));
        }
        $this->load->language('saccount/extension');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('saccount/product');

        $this->getList();
    }

    public function insert() {

        if (!$this->seller->isLogged()) {
            $this->session->data['redirect'] = $this->url->link('saccount/extension/insert&market_id='.$this->session->data['session_market_id'], '', 'SSL');

            $this->response->redirect($this->url->link('common/landing', '', 'SSL'));
        }
        $this->load->language('saccount/extension');

        $this->document->setTitle($this->language->get('heading_title1'));

        $this->load->model('saccount/product');


        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {

            $product_filter = array();
            if (!empty($this->request->post['condition'])) {
                array_push($product_filter, $this->request->post['condition']);
            }
            if (!empty($this->request->post['colour'])) {
                $product_filter = array_merge((array) $this->request->post['colour'], (array) $product_filter);
            }
            $this->request->post['product_filter'] = $product_filter;
            if (!empty($this->request->post['data']['shipping_preference'])) {
                if ($this->request->post['data']['shipping_preference'] != 1) {
                    $this->request->post['shipping'] = 1;
                } else {
                    $this->request->post['shipping'] = 0;
                }
            } else {
                $this->request->post['shipping'] = 0;
            }
			
					// For calculating price on behalf of shiping preference
				
			if($this->seller->getShippingPreference()== 2 && (isset($this->request->post['weight']) && isset($this->request->post['length']) && isset($this->request->post['width']) && isset($this->request->post['height']))){
			
			
			$seller_shipping_ser=$this->db->query("Select * FROM " . DB_PREFIX . "seller_shipping where seller_id='".$this->seller->getId()."'");
			if(!empty($seller_shipping_ser)){
				$var_s=json_decode($seller_shipping_ser->row['shipping_service']);
				if($var_s[0]==2){
					
				$service = '03';
		        $ups_price=$this->ups($seller_shipping_ser->row['zipcode'],'03',$this->request->post['weight'],(int)$this->request->post['length'],(int)$this->request->post['width'],(int)$this->request->post['height']);
				}else if($var_s[0]== 1){
					
					$services['fedex']['FEDEXGROUND'] = 'Ground';

					$config = array(
						// Services
						'services' => $services,
						// Weight
						'weight' => (int)$this->request->post['weight'], // Default = 1
						'weight_units' => 'lb', // lb (default), oz, gram, kg
						// Size
						'size_length' => (int)$this->request->post['length'], // Default = 8
						'size_width' => (int)$this->request->post['width'], // Default = 4
						'size_height' => (int)$this->request->post['height'], // Default = 2
						'size_units' => 'in', // in (default), feet, cm
						// From
						'from_zip' => 97210,
						'from_state' => "OR", // Only Required for FedEx
						'from_country' => "US",
						// To
						'to_zip' => $seller_shipping_ser->row['zipcode'],
						'to_state' => "MN", // Only Required for FedEx
						'to_country' => "US",
						// Service Logins
						'ups_access' => '', // UPS Access License Key
						'ups_user' => '', // UPS Username  
						'ups_pass' => '', // UPS Password  
						'ups_account' => '', // UPS Account Number
						'usps_user' => '', // USPS User Name
						/* 'fedex_account' => '604501202', // FedEX Account Number coolteam
						  'fedex_meter' => '118719802' // FedEx Meter Number coolteam */
						'fedex_account' => '510087542', // client testing account
						'fedex_meter' => '118719771'  // client testing meter
					);
                  
				 $ship = new FedexAPI($config);
// Get Rates
               $rates = $ship->calculate();print_r($rates);
			    $fed_price=$rates['fedex']['FEDEXGROUND'];

				}else if($var_s[0]== 3){
					 $usps_price=$this->USPSParcelRate($this->request->post['weight'],$seller_shipping_ser->row['zipcode']);
				}
				
			}
		   // echo $ups_price; die;
		}
		
		if($this->request->post['price'] && $this->request->post['price'] != '0.00'){
				$this->request->post['price'] = str_replace('$', '', $this->request->post['price']);
				$this->request->post['price'] = str_replace(',', '', trim($this->request->post['price']));
			} else {
				$this->request->post['price'] = 0;
			}
		
		if(isset($ups_price) && !empty($ups_price)){
			$this->request->post['price']=$this->request->post['price']+$ups_price;
		}
		
		if(isset($fed_price) && !empty($fed_price)){
			$this->request->post['price']=$this->request->post['price']+$fed_price;
		}
		
		
		if(isset($usps_price) && !empty($usps_price)){
			$this->request->post['price']=$this->request->post['price']+$usps_price;
		}
		
	

            // check if seller has active subscription or not.
            $sub_status = $this->model_saccount_product->checkSellerPackage($this->seller->getId());

            if ($sub_status == 0) {
                // seller is not subscribed. modify the status
                // auto approve product
                $this->request->post['approve'] = 3;
                $this->request->post['status'] = 3;
            } else {
                // seller is subscribed.
                // auto approve product
                $this->request->post['approve'] = 1;
                $this->request->post['status'] = 1;
            }

            $this->model_saccount_product->addProduct($this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');

            $url = '';

            if (isset($this->request->get['filter_name1'])) {
                $url .= '&filter_name1=' . $this->request->get['filter_name1'];
            }

            if (isset($this->request->get['filter_model'])) {
                $url .= '&filter_model=' . $this->request->get['filter_model'];
            }

            if (isset($this->request->get['filter_price'])) {
                $url .= '&filter_price=' . $this->request->get['filter_price'];
            }

            if (isset($this->request->get['filter_quantity'])) {
                $url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
            }

            if (isset($this->request->get['sort'])) {
                $url .= '&sort=' . $this->request->get['sort'];
            }

            if (isset($this->request->get['order'])) {
                $url .= '&order=' . $this->request->get['order'];
            }

            if (isset($this->request->get['page'])) {
                $url .= '&page=' . $this->request->get['page'];
            }
           if(isset($this->request->get['next_val']) && $this->request->get['next_val']==1){
			  
                $this->response->redirect($this->url->link('saccount/extension/insert', $url, 'SSL'));
				
		   }else{
            if ($sub_status == 0) {
                // seller is not subscribed. redirect to subscribe page
				if($this->session->data['session_market_id'] ==2){
				 $this->response->redirect($this->url->link('saccount/funding&market_id='.$this->session->data['session_market_id'], $url, 'SSL'));
				}else{
                $this->response->redirect($this->url->link('saccount/subscribe&market_id='.$this->session->data['session_market_id'], $url, 'SSL'));
				}
            } else {
                // seller is subscribed.
                $this->response->redirect($this->url->link('product/seller&market_id='.$this->session->data['session_market_id'], 'seller_id='.$this->seller->getId(), 'SSL'));
            }
		   }
        }

        $this->getForm('product_form');
    }

    public function update() {
        if (!$this->seller->isLogged()) {
            $this->session->data['redirect'] = $this->url->link('saccount/extension', '', 'SSL');

            $this->response->redirect($this->url->link('common/landing', '', 'SSL'));
        }
        $this->load->language('saccount/extension');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('saccount/product');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateUpdateForm()) {
            $product_filter = array();
            if (!empty($this->request->post['condition'])) {
                array_push($product_filter, $this->request->post['condition']);
            }
            if (!empty($this->request->post['colour'])) {
                $product_filter = array_merge((array) $this->request->post['colour'], (array) $product_filter);
            }
            $this->request->post['product_filter'] = $product_filter;
            // auto approve product
            $this->request->post['approve'] = 1;
            if (!empty($this->request->post['data']['shipping_preference'])) {
                if ($this->request->post['data']['shipping_preference'] != 1) {
                    $this->request->post['shipping'] = 1;
                } else {
                    $this->request->post['shipping'] = 0;
                }
            } else {
                $this->request->post['shipping'] = 0;
            }
			
			// For calculating price on behalf of shiping preference
				
			if($this->seller->getShippingPreference()== 2 && (isset($this->request->post['weight']) && isset($this->request->post['length']) && isset($this->request->post['width']) && isset($this->request->post['height']))){
			
			
			$seller_shipping_ser=$this->db->query("Select * FROM " . DB_PREFIX . "seller_shipping where seller_id='".$this->seller->getId()."'");
			if(!empty($seller_shipping_ser)){
				$var_s=json_decode($seller_shipping_ser->row['shipping_service']);
				if($var_s[0]==2){
					
				$service = '03';
		        $ups_price=$this->ups($seller_shipping_ser->row['zipcode'],'03',$this->request->post['weight'],(int)$this->request->post['length'],(int)$this->request->post['width'],(int)$this->request->post['height']);
				}else if($var_s[0]== 1){
					
					$services['fedex']['FEDEXGROUND'] = 'Ground';

					$config = array(
						// Services
						'services' => $services,
						// Weight
						'weight' => (int)$this->request->post['weight'], // Default = 1
						'weight_units' => 'lb', // lb (default), oz, gram, kg
						// Size
						'size_length' => (int)$this->request->post['length'], // Default = 8
						'size_width' => (int)$this->request->post['width'], // Default = 4
						'size_height' => (int)$this->request->post['height'], // Default = 2
						'size_units' => 'in', // in (default), feet, cm
						// From
						'from_zip' => 97210,
						'from_state' => "OR", // Only Required for FedEx
						'from_country' => "US",
						// To
						'to_zip' => $seller_shipping_ser->row['zipcode'],
						'to_state' => "MN", // Only Required for FedEx
						'to_country' => "US",
						// Service Logins
						'ups_access' => '', // UPS Access License Key
						'ups_user' => '', // UPS Username  
						'ups_pass' => '', // UPS Password  
						'ups_account' => '', // UPS Account Number
						'usps_user' => '', // USPS User Name
						/* 'fedex_account' => '604501202', // FedEX Account Number coolteam
						  'fedex_meter' => '118719802' // FedEx Meter Number coolteam */
						'fedex_account' => '510087542', // client testing account
						'fedex_meter' => '118719771'  // client testing meter
					);
                  
				 $ship = new FedexAPI($config);
// Get Rates
               $rates = $ship->calculate();print_r($rates);
			    $fed_price=$rates['fedex']['FEDEXGROUND'];

				}else if($var_s[0]== 3){
					 $usps_price=$this->USPSParcelRate($this->request->post['weight'],$seller_shipping_ser->row['zipcode']);
				}
				
			}
		   // echo $ups_price; die;
		}
		if($this->request->post['price'] && $this->request->post['price'] != '0.00'){
				$this->request->post['price'] = str_replace('$', '', $this->request->post['price']);
				$this->request->post['price'] = str_replace(',', '', trim($this->request->post['price']));
			} else {
				$this->request->post['price'] = 0;
			}
			
		if(isset($ups_price) && !empty($ups_price)){
			$this->request->post['price']=$this->request->post['price']+$ups_price;
		}
		
		if(isset($fed_price) && !empty($fed_price)){
			$this->request->post['price']=$this->request->post['price']+$fed_price;
		}
		
		if(isset($usps_price) && !empty($usps_price)){
			$this->request->post['price']=$this->request->post['price']+$usps_price;
		}
		
	

            // check if seller has active subscription or not.
            $sub_status = $this->model_saccount_product->checkSellerPackage($this->seller->getId());

            if ($sub_status == 0) {
                // seller is not subscribed. modify the status
                // auto approve product
                $this->request->post['approve'] = 3;
                $this->request->post['status'] = 3;
            } else {
                // seller is subscribed.
                // auto approve product
                $this->request->post['approve'] = 1;
                $this->request->post['status'] = 1;
            }

            $this->model_saccount_product->editProduct($this->request->get['product_id'], $this->request->post);

            $this->session->data['success'] = $this->language->get('text_modify');

            $url = '';

            if (isset($this->request->get['filter_name1'])) {
                $url .= '&filter_name1=' . $this->request->get['filter_name1'];
            }

            if (isset($this->request->get['filter_model'])) {
                $url .= '&filter_model=' . $this->request->get['filter_model'];
            }

            if (isset($this->request->get['filter_price'])) {
                $url .= '&filter_price=' . $this->request->get['filter_price'];
            }

            if (isset($this->request->get['filter_quantity'])) {
                $url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
            }

            if (isset($this->request->get['sort'])) {
                $url .= '&sort=' . $this->request->get['sort'];
            }

            if (isset($this->request->get['order'])) {
                $url .= '&order=' . $this->request->get['order'];
            }

            if (isset($this->request->get['page'])) {
                $url .= '&page=' . $this->request->get['page'];
            }

            if ($sub_status == 0) {
                // seller is not subscribed. redirect to subscribe page
				if($this->session->data['session_market_id'] ==2){
				 $this->response->redirect($this->url->link('saccount/funding&market_id='.$this->session->data['session_market_id'], $url, 'SSL'));
				}else{
                $this->response->redirect($this->url->link('saccount/subscribe&market_id='.$this->session->data['session_market_id'], $url, 'SSL'));
				}
            } else {
                // seller is subscribed.
                $this->response->redirect($this->url->link('product/seller&market_id='.$this->session->data['session_market_id'],'seller_id='.$this->seller->getId(), 'SSL'));
            }
        }

        $this->getForm();
    }

    public function delete() {
        if (!$this->seller->isLogged()) {
            $this->session->data['redirect'] = $this->url->link('saccount/extension', '', 'SSL');

            $this->response->redirect($this->url->link('common/landing', '', 'SSL'));
        }
        $this->load->language('saccount/extension');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('saccount/product');

        if (isset($this->request->get['selected']) && $this->validateDelete()) {
            /* foreach ($this->request->get['selected'] as $product_id) {
				$this->model_saccount_product->deleteProduct($product_id);
            } */
			$product_id = $this->request->get['selected'];
			$this->model_saccount_product->deleteProduct($product_id);

            $this->session->data['success'] = $this->language->get('text_delete');

            $url = '';

            if (isset($this->request->get['filter_name1'])) {
                $url .= '&filter_name1=' . $this->request->get['filter_name1'];
            }

            if (isset($this->request->get['filter_model'])) {
                $url .= '&filter_model=' . $this->request->get['filter_model'];
            }

            if (isset($this->request->get['filter_price'])) {
                $url .= '&filter_price=' . $this->request->get['filter_price'];
            }

            if (isset($this->request->get['filter_quantity'])) {
                $url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
            }

            if (isset($this->request->get['sort'])) {
                $url .= '&sort=' . $this->request->get['sort'];
            }

            if (isset($this->request->get['order'])) {
                $url .= '&order=' . $this->request->get['order'];
            }

            if (isset($this->request->get['page'])) {
                $url .= '&page=' . $this->request->get['page'];
            }

            $this->response->redirect($this->url->link('product/seller', 'seller_id='.$this->seller->getId(), 'SSL'));
        }

        $this->getList();
    }

    public function copy() {
        if (!$this->seller->isLogged()) {
            $this->session->data['redirect'] = $this->url->link('saccount/extension', '', 'SSL');

            $this->response->redirect($this->url->link('common/landing', '', 'SSL'));
        }
        $this->load->language('saccount/extension');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('saccount/product');

        if (isset($this->request->post['selected']) && $this->validateCopy()) {
            foreach ($this->request->post['selected'] as $product_id) {
                $this->model_saccount_product->copyProduct($product_id);
            }

            $this->session->data['success'] = $this->language->get('text_success');

            $url = '';

            if (isset($this->request->get['filter_name1'])) {
                $url .= '&filter_name1=' . $this->request->get['filter_name1'];
            }

            if (isset($this->request->get['filter_model'])) {
                $url .= '&filter_model=' . $this->request->get['filter_model'];
            }

            if (isset($this->request->get['filter_price'])) {
                $url .= '&filter_price=' . $this->request->get['filter_price'];
            }

            if (isset($this->request->get['filter_quantity'])) {
                $url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
            }


            if (isset($this->request->get['sort'])) {
                $url .= '&sort=' . $this->request->get['sort'];
            }

            if (isset($this->request->get['order'])) {
                $url .= '&order=' . $this->request->get['order'];
            }

            if (isset($this->request->get['page'])) {
                $url .= '&page=' . $this->request->get['page'];
            }

            $this->response->redirect($this->url->link('saccount/extension', $url, 'SSL'));
        }

        $this->getList();
    }

    private function getList() {
        if (isset($this->request->get['filter_name1'])) {
            $filter_name1 = $this->request->get['filter_name1'];
        } else {
            $filter_name1 = null;
        }

        if (isset($this->request->get['filter_model'])) {
            $filter_model = $this->request->get['filter_model'];
        } else {
            $filter_model = null;
        }

        if (isset($this->request->get['filter_sku'])) {
            $filter_sku = $this->request->get['filter_sku'];
        } else {
            $filter_sku = null;
        }

        if (isset($this->request->get['filter_price'])) {
            $filter_price = $this->request->get['filter_price'];
        } else {
            $filter_price = null;
        }

        if (isset($this->request->get['filter_quantity'])) {
            $filter_quantity = $this->request->get['filter_quantity'];
        } else {
            $filter_quantity = null;
        }



        if (isset($this->request->get['filter_seller'])) {
            $filter_seller = $this->request->get['filter_seller'];
        } else {
            $filter_seller = NULL;
        }

        if (isset($this->request->get['sort'])) {
            $sort = $this->request->get['sort'];
        } else {
            $sort = 'pd.name';
        }

        if (isset($this->request->get['order'])) {
            $order = $this->request->get['order'];
        } else {
            $order = 'ASC';
        }

        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }

        $url = '';

        if (isset($this->request->get['filter_name1'])) {
            $url .= '&filter_name1=' . $this->request->get['filter_name1'];
        }

        if (isset($this->request->get['filter_model'])) {
            $url .= '&filter_model=' . $this->request->get['filter_model'];
        }

        if (isset($this->request->get['filter_sku'])) {
            $url .= '&filter_sku=' . $this->request->get['filter_sku'];
        }

        if (isset($this->request->get['filter_price'])) {
            $url .= '&filter_price=' . $this->request->get['filter_price'];
        }

        if (isset($this->request->get['filter_quantity'])) {
            $url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
        }



        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home', '', 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => 'Account',
            'href' => $this->url->link('saccount/account', '', 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('saccount/extension', '', 'SSL')
        );

        $data['insert'] = $this->url->link('saccount/extension/insert', '', 'SSL');
        $data['copy'] = $this->url->link('saccount/extension/copy', '', 'SSL');
        $data['delete'] = $this->url->link('saccount/extension/delete', '', 'SSL');

        $data['products'] = array();

        $filterdata = array(
            'filter_name1' => $filter_name1,
            'filter_model' => $filter_model,
            'filter_sku' => $filter_sku,
            'filter_seller' => $filter_seller,
            'filter_price' => $filter_price,
            'filter_quantity' => $filter_quantity,
            'sort' => $sort,
            'order' => $order,
            'start' => ($page - 1) * $this->config->get('config_admin_limit'),
            'limit' => $this->config->get('config_admin_limit')
        );
        $seller_id = $this->seller->getId();
        $this->load->model('tool/image');
		$this->load->model('catalog/seller');
		
		$seller_info = $this->model_catalog_seller->getSeller($seller_id);		
		$data['seller_id']= $seller_id;
		$data['folder_name'] = $seller_info['foldername'];

        $product_total = $this->model_saccount_product->getTotalProducts($filterdata, $this->seller->getId());

        $results = $this->model_saccount_product->getProducts($filterdata, $this->seller->getId());

        foreach ($results as $result) {
            $action = array();

            $action[] = array(
                'text' => $this->language->get('text_edit'),
                'href' => $this->url->link('saccount/extension/update', 'product_id=' . $result['product_id'] . $url, 'SSL')
            );

            if ($result['image'] && file_exists(DIR_IMAGE . $result['image'])) {
                $image = $this->model_tool_image->resize($result['image'], 40, 40);
            } else {
                $image = $this->model_tool_image->resize('no_image.png', 40, 40);
            }

            $special = false;

            $product_specials = $this->model_saccount_product->getProductSpecials($result['product_id']);

            foreach ($product_specials as $product_special) {
                if (($product_special['date_start'] == '0000-00-00' || $product_special['date_start'] > date('Y-m-d')) && ($product_special['date_end'] == '0000-00-00' || $product_special['date_end'] < date('Y-m-d'))) {
                    $special = $product_special['price'];

                    break;
                }
            }

            $this->load->model('saccount/download');
            //$download_total = $this->model_saccount_download->getTotalExtensionDownload($result['product_id']);
            $data['products'][] = array(
                'product_id' => $result['product_id'],
                'name' => $result['name'],
                'date_added' => $result['date_added'],
                'model' => $result['model'],
                'price' => $result['price'],
                'sku' => $result['sku'],
                'special' => $special,
                'image' => $image,
                'quantity' => $result['quantity'],
                'status' => ($result['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
                'selected' => isset($this->request->post['selected']) && in_array($result['product_id'], $this->request->post['selected']),
                'edit' => $this->url->link('saccount/extension/update', 'product_id=' . $result['product_id'] . $url, 'SSL')
            );
        }

        $data['heading_title'] = $this->language->get('heading_title');
        $data['new_extensions'] = sprintf($this->language->get('new_extensions'), $this->url->link('saccount/extension/insert', '', 'SSL'));
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_no_results'] = $this->language->get('text_no_results');
        $data['text_image_manager'] = $this->language->get('text_image_manager');
        $data['text_confirm'] = $this->language->get('text_confirm');
        $data['column_name'] = $this->language->get('column_name');
        $data['column_date_added'] = $this->language->get('column_date_added');
        $data['column_status'] = $this->language->get('column_status');
        $data['column_action'] = $this->language->get('column_action');
        $data['column_downloads'] = $this->language->get('column_downloads');
        $data['button_copy'] = $this->language->get('button_copy');
        $data['button_insert'] = $this->language->get('button_insert');
        $data['button_delete'] = $this->language->get('button_delete');
        $data['button_filter'] = $this->language->get('button_filter');

        $data['button_edit'] = $this->language->get('button_edit');


        /*         * NEW ADDED CODE* */

        $data['column_image'] = $this->language->get('column_image');
        $data['column_model'] = $this->language->get('column_model');
        $data['column_price'] = $this->language->get('column_price');
        $data['column_quantity'] = $this->language->get('column_quantity');


        $data['text_list'] = $this->language->get('text_list');


        $data['entry_name'] = $this->language->get('entry_name');
        $data['entry_model'] = $this->language->get('entry_model');
        $data['entry_price'] = $this->language->get('entry_price');
        $data['entry_quantity'] = $this->language->get('entry_quantity');
        $data['entry_status'] = $this->language->get('entry_status');

        $data['same_id'] = 1;
        $data['seller_id'] = $this->seller->getId();
        $data['seller_group_id'] = $this->session->data['session_market_id'];

        if (isset($this->session->data['token'])) {
            $data['token'] = $this->session->data['token'];
        } else {
            $data['token'] = '';
        }

        /**/

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];

            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }

        if (isset($this->request->post['selected'])) {
            $data['selected'] = (array) $this->request->post['selected'];
        } else {
            $data['selected'] = array();
        }
        $url = '';

        if (isset($this->request->get['filter_name1'])) {
            $url .= '&filter_name1=' . $this->request->get['filter_name1'];
        }

        if (isset($this->request->get['filter_model'])) {
            $url .= '&filter_model=' . $this->request->get['filter_model'];
        }

        if (isset($this->request->get['filter_sku'])) {
            $url .= '&filter_sku=' . $this->request->get['filter_sku'];
        }

        if (isset($this->request->get['filter_price'])) {
            $url .= '&filter_price=' . $this->request->get['filter_price'];
        }

        if (isset($this->request->get['filter_quantity'])) {
            $url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
        }



        if ($order == 'ASC') {
            $url .= '&order=DESC';
        } else {
            $url .= '&order=ASC';
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['sort_name'] = $this->url->link('saccount/extension', 'sort=pd.name' . $url, 'SSL');
        $data['sort_model'] = $this->url->link('saccount/extension', 'sort=p.model' . $url, 'SSL');
        $data['sort_sku'] = $this->url->link('saccount/extension', 'sort=p.sku' . $url, 'SSL');
        $data['sort_price'] = $this->url->link('saccount/extension', 'sort=p.price' . $url, 'SSL');
        $data['sort_quantity'] = $this->url->link('saccount/extension', 'sort=p.quantity' . $url, 'SSL');
        $data['sort_order'] = $this->url->link('saccount/extension', 'sort=p.sort_order' . $url, 'SSL');

        $url = '';

        if (isset($this->request->get['filter_name1'])) {
            $url .= '&filter_name1=' . $this->request->get['filter_name1'];
        }

        if (isset($this->request->get['filter_model'])) {
            $url .= '&filter_model=' . $this->request->get['filter_model'];
        }

        if (isset($this->request->get['filter_sku'])) {
            $url .= '&filter_sku=' . $this->request->get['filter_sku'];
        }

        if (isset($this->request->get['filter_price'])) {
            $url .= '&filter_price=' . $this->request->get['filter_price'];
        }

        if (isset($this->request->get['filter_quantity'])) {
            $url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
        }



        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        $pagination = new Pagination();
        $pagination->total = $product_total;
        $pagination->page = $page;
        $pagination->limit = $this->config->get('config_admin_limit');
        $pagination->text = $this->language->get('text_pagination');
        $pagination->url = $this->url->link('saccount/extension', $url . '&page={page}', 'SSL');

        $data['pagination'] = $pagination->render();

        $data['results'] = sprintf($this->language->get('text_pagination'), ($product_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($product_total - $this->config->get('config_limit_admin'))) ? $product_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $product_total, ceil($product_total / $this->config->get('config_limit_admin')));


        $data['filter_name1'] = $filter_name1;
        $data['filter_model'] = $filter_model;
        $data['filter_sku'] = $filter_sku;
        $data['filter_price'] = $filter_price;
        $data['filter_quantity'] = $filter_quantity;


        $data['sort'] = $sort;
        $data['order'] = $order;
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['column_right'] = $this->load->controller('common/column_right');
        $data['content_top'] = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/header');
        $data['seller_right'] = $this->load->controller('product/seller_right');
        $data['seller_profile'] = $this->load->controller('product/seller_profile');
        $data['seller_billboard'] = $this->load->controller('product/seller_billboard');
        $data['seller_marketplace'] = $this->load->controller('product/seller_marketplace');


        if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/saccount/product_list.tpl')) {
            $this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/saccount/product_list.tpl', $data));
        } else {
            $this->response->setOutput($this->load->view('default/template/saccount/product_list.tpl', $data));
        }
    }

    public function captcha() {
        $this->load->library('captcha');

        $captcha = new Captcha();

        $this->session->data['captcha'] = $captcha->getCode();

        $captcha->showImage();
    }

    private function getForm($use_template = null) {
		

        $data['same_id'] = 1;
        $data['seller_id'] = $this->seller->getId();
        $data['seller_group_id'] = $this->session->data['session_market_id'];
        $data['heading_title1'] = $this->language->get('heading_title1');
        $this->load->model('saccount/additem');

        $additem_categories = $this->model_saccount_additem->getcategory();
		
		$this->load->model('saccount/additem');
		 
		 $data['categories_f'] = $this->model_saccount_additem->getFundcategory();


        //$data=array();

        $children_data = array();
        foreach ($additem_categories as $additem_category) {
            $children = $this->model_saccount_additem->getcategory($additem_category['category_id']);

            foreach ($children as $child) {
                $children_data[$additem_category['category_id']][] = array(
                    'category_id' => $child['category_id'],
                    'name' => $child['name'],
                );
            }
        }

        $this->language->load('saccount/shipping');
        $data['text_shipping'] = $this->language->get('text_shipping');
        $data['entry_pick'] = $this->language->get('entry_pick');
        $data['entry_delivery'] = $this->language->get('entry_delivery');
        $data['entry_seller'] = $this->language->get('entry_seller');

        $data['seller_fund_total'] = $this->model_saccount_additem->getSellerFundTotal();
        $data['seller_fund_products'] = $this->model_saccount_additem->getSellerFundProducts();
        $data['fund_products'] = $this->model_saccount_additem->getFundProducts();
	    //print_r($data['seller_fund_products']);
		//echo "SELECT category_id FROM " . DB_PREFIX . "product_to_category WHERE product_id = '" . (int) $data['seller_fund_products'][0] . "'";
		$seller_product_val=$this->db->query("SELECT product_id FROM " . DB_PREFIX . "product WHERE seller_id = '" . (int) $this->seller->getId() . "'");
		
	    $fun_category_sel= $this->db->query("SELECT category_id FROM " . DB_PREFIX . "product_to_category WHERE product_id = '" . (int) $seller_product_val->row['product_id'] . "'");
		$data['selected_product_categories_f'] =$fun_category_sel->row;
        $data['additem_categories'] = $additem_categories;
        $data['child_categories'] = $children_data;

        $data['colour_filters'] = $this->model_saccount_additem->getColourFilters();
        $data['condition_filters'] = $this->model_saccount_additem->getConditionFilters();

        $data['product_filters'] = array();

        $data['entry_name'] = $this->language->get('entry_name');
        $data['entry_description'] = $this->language->get('entry_description');
        $data['entry_meta_title'] = $this->language->get('entry_meta_title');
        $data['entry_meta_description'] = $this->language->get('entry_meta_description');
        $data['entry_meta_keyword'] = $this->language->get('entry_meta_keyword');
        $data['entry_keyword'] = $this->language->get('entry_keyword');
        $data['entry_model'] = $this->language->get('entry_model');
        $data['entry_sku'] = $this->language->get('entry_sku');
        $data['entry_upc'] = $this->language->get('entry_upc');
        $data['entry_ean'] = $this->language->get('entry_ean');
        $data['entry_jan'] = $this->language->get('entry_jan');
        $data['entry_isbn'] = $this->language->get('entry_isbn');
        $data['entry_mpn'] = $this->language->get('entry_mpn');
        $data['entry_location'] = $this->language->get('entry_location');
        $data['entry_minimum'] = $this->language->get('entry_minimum');
        $data['entry_shipping'] = $this->language->get('entry_shipping');
        $data['entry_date_available'] = $this->language->get('entry_date_available');
        $data['entry_quantity'] = $this->language->get('entry_quantity');
        $data['entry_stock_status'] = $this->language->get('entry_stock_status');
        $data['entry_price'] = $this->language->get('entry_price');
        $data['entry_tax_class'] = $this->language->get('entry_tax_class');
        $data['entry_points'] = $this->language->get('entry_points');
        $data['entry_option_points'] = $this->language->get('entry_option_points');
        $data['entry_subtract'] = $this->language->get('entry_subtract');
        $data['entry_weight_class'] = $this->language->get('entry_weight_class');
        $data['entry_weight'] = $this->language->get('entry_weight');
        $data['entry_dimension'] = $this->language->get('entry_dimension');
        $data['entry_length_class'] = $this->language->get('entry_length_class');
        $data['entry_length'] = $this->language->get('entry_length');
        $data['entry_width'] = $this->language->get('entry_width');
        $data['entry_height'] = $this->language->get('entry_height');
        $data['entry_image'] = $this->language->get('entry_image');
        $data['entry_store'] = $this->language->get('entry_store');
        $data['entry_manufacturer'] = $this->language->get('entry_manufacturer');
        $data['entry_download'] = $this->language->get('entry_download');
        $data['entry_category'] = $this->language->get('entry_category');
        $data['entry_filter'] = $this->language->get('entry_filter');
        $data['entry_related'] = $this->language->get('entry_related');
        $data['entry_attribute'] = $this->language->get('entry_attribute');
        $data['entry_text'] = $this->language->get('entry_text');
        $data['entry_option'] = $this->language->get('entry_option');
        $data['entry_option_value'] = $this->language->get('entry_option_value');
        $data['entry_required'] = $this->language->get('entry_required');
        $data['entry_sort_order'] = $this->language->get('entry_sort_order');
        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_date_start'] = $this->language->get('entry_date_start');
        $data['entry_date_end'] = $this->language->get('entry_date_end');
        $data['entry_priority'] = $this->language->get('entry_priority');
        $data['entry_tag'] = $this->language->get('entry_tag');
        $data['entry_customer_group'] = $this->language->get('entry_customer_group');
        $data['entry_reward'] = $this->language->get('entry_reward');
        $data['entry_layout'] = $this->language->get('entry_layout');
        $data['entry_recurring'] = $this->language->get('entry_recurring');

        $data['help_keyword'] = $this->language->get('help_keyword');
        $data['help_sku'] = $this->language->get('help_sku');
        $data['help_upc'] = $this->language->get('help_upc');
        $data['help_ean'] = $this->language->get('help_ean');
        $data['help_jan'] = $this->language->get('help_jan');
        $data['help_isbn'] = $this->language->get('help_isbn');
        $data['help_mpn'] = $this->language->get('help_mpn');
        $data['help_minimum'] = $this->language->get('help_minimum');
        $data['help_manufacturer'] = $this->language->get('help_manufacturer');
        $data['help_stock_status'] = $this->language->get('help_stock_status');
        $data['help_points'] = $this->language->get('help_points');
        $data['help_category'] = $this->language->get('help_category');
        $data['help_filter'] = $this->language->get('help_filter');
        $data['help_download'] = $this->language->get('help_download');
        $data['help_related'] = $this->language->get('help_related');
        $data['help_tag'] = $this->language->get('help_tag');

        $data['button_save'] = $this->language->get('button_save');
        $data['button_upload'] = $this->language->get('button_upload');
        $data['button_cancel'] = $this->language->get('button_cancel');
        $data['button_attribute_add'] = $this->language->get('button_attribute_add');
        $data['button_option_add'] = $this->language->get('button_option_add');
        $data['button_option_value_add'] = $this->language->get('button_option_value_add');
        $data['button_discount_add'] = $this->language->get('button_discount_add');
        $data['button_special_add'] = $this->language->get('button_special_add');
        $data['button_image_add'] = $this->language->get('button_image_add');
        $data['button_remove'] = $this->language->get('button_remove');
        $data['button_recurring_add'] = $this->language->get('button_recurring_add');

        $data['tab_general'] = $this->language->get('tab_general');
        $data['tab_data'] = $this->language->get('tab_data');
        $data['tab_attribute'] = $this->language->get('tab_attribute');
        $data['tab_option'] = $this->language->get('tab_option');
        $data['tab_recurring'] = $this->language->get('tab_recurring');
        $data['tab_discount'] = $this->language->get('tab_discount');
        $data['tab_special'] = $this->language->get('tab_special');
        $data['tab_image'] = $this->language->get('tab_image');
        $data['tab_links'] = $this->language->get('tab_links');
        $data['tab_reward'] = $this->language->get('tab_reward');
        $data['tab_design'] = $this->language->get('tab_design');
        $data['tab_openbay'] = $this->language->get('tab_openbay');


        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_none'] = $this->language->get('text_none');
        $data['text_yes'] = $this->language->get('text_yes');
        $data['text_no'] = $this->language->get('text_no');
        $data['text_plus'] = $this->language->get('text_plus');
        $data['text_minus'] = $this->language->get('text_minus');
        $data['text_default'] = $this->language->get('text_default');
        $data['text_option'] = $this->language->get('text_option');
        $data['text_option_value'] = $this->language->get('text_option_value');
        $data['text_select'] = $this->language->get('text_select');
        $data['text_percent'] = $this->language->get('text_percent');
        $data['text_amount'] = $this->language->get('text_amount');
        $data['text_image_manager'] = $this->language->get('text_image_manager');

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];

            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }

        if (isset($this->error['name'])) {
            $data['error_name'] = $this->error['name'];
        } else {
            $data['error_name'] = array();
        }

        if (isset($this->error['name'])) {
            $data['error_name'] = $this->error['name'];
        } else {
            $data['error_name'] = array();
        }
		
		if (isset($this->error['lname'])) {
            $data['error_lname'] = $this->error['lname'];
        } else {
            $data['error_lname'] = array();
        }
		
		if (isset($this->error['wname'])) {
            $data['error_wname'] = $this->error['wname'];
        } else {
            $data['error_wname'] = array();
        }
		
		if (isset($this->error['hname'])) {
            $data['error_hname'] = $this->error['hname'];
        } else {
            $data['error_hname'] = array();
        }
		
		if (isset($this->error['wename'])) {
            $data['error_wename'] = $this->error['wename'];
        } else {
            $data['error_wename'] = array();
        }

        if (isset($this->error['maximum_limit'])) {
            $data['maximum_limit'] = $this->error['maximum_limit'];
        } else {
            $data['maximum_limit'] = array();
        }

        if (isset($this->error['meta_description'])) {
            $data['error_meta_description'] = $this->error['meta_description'];
        } else {
            $data['error_meta_description'] = array();
        }

        if (isset($this->error['description'])) {
            $data['error_description'] = $this->error['description'];
        } else {
            $data['error_description'] = array();
        }

        if (isset($this->error['price'])) {
            $data['error_price'] = $this->error['price'];
        } else {
            $data['error_price'] = "";
        }

        if (isset($this->error['model'])) {
            $data['error_model'] = $this->error['model'];
        } else {
            $data['error_model'] = "";
        }

        if (isset($this->error['captcha'])) {
            $data['error_captcha'] = $this->error['captcha'];
        } else {
            $data['error_captcha'] = '';
        }

        if (isset($this->error['date_available'])) {
            $data['error_date_available'] = $this->error['date_available'];
        } else {
            $data['error_date_available'] = '';
        }

        /*         * NEW ADDED CODE* */

        if (isset($this->error['model'])) {
            $data['error_model'] = $this->error['model'];
        } else {
            $data['error_model'] = '';
        }
        /**/

        $url = '';

        if (isset($this->request->get['filter_name1'])) {
            $url .= '&filter_name1=' . $this->request->get['filter_name1'];
        }

        if (isset($this->request->get['filter_sku'])) {
            $url .= '&filter_sku=' . $this->request->get['filter_sku'];
        }

        if (isset($this->request->get['filter_model'])) {
            $url .= '&filter_model=' . $this->request->get['filter_model'];
        }

        if (isset($this->request->get['filter_price'])) {
            $url .= '&filter_price=' . $this->request->get['filter_price'];
        }

        if (isset($this->request->get['filter_quantity'])) {
            $url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
        }


        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        if (isset($this->request->post['captcha'])) {
            $data['captcha'] = $this->request->post['captcha'];
        } else {
            $data['captcha'] = '';
        }
		
		 $this->load->model('saccount/seller');
		
		$seller_info = $this->model_saccount_seller->getSeller($this->seller->getId());
		
		if (isset($this->request->post['aboutus'])) {
    		$data['aboutus'] = $this->request->post['aboutus'];
		}elseif (isset($seller_info)) {
			$data['aboutus'] = $seller_info['aboutus'];
		}   else {
			$data['aboutus'] = '';
		}

        if (isset($this->error['download'])) {
            $data['error_download'] = $this->error['download'];
        } else {
            $data['error_download'] = '';
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home', '', 'SSL'),
            'separator' => false
        );

        $data['breadcrumbs'][] = array(
            'text' => 'Account',
            'href' => $this->url->link('saccount/account', $url, 'SSL'),
            'separator' => ' :: '
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title1'),
            'href' => $this->url->link('saccount/extension', $url, 'SSL'),
            'separator' => ' :: '
        );



        if (!isset($this->request->get['product_id'])) {
            if ($this->session->data['session_market_id'] == 1) {
                $data['action'] = $this->url->link('saccount/extension/insert', $url, 'SSL');
            } else {
                $act = 'add';
                if($use_template == 'product_fundraiser_form') {
					$this->load->model('catalog/seller'); $this->load->model('saccount/product');
         $data['total_item'] = $this->model_catalog_seller->getTotalSellerProducts();
        $data['seller_plan_item'] = $this->model_catalog_seller->getSellerPaymentmode();
                    $act = 'addproduct';
                }
                $data['action'] = $this->url->link('saccount/extension/'.$act, $url, 'SSL');
            }
        } else {
			$this->load->model('catalog/seller'); $this->load->model('saccount/product');
         $data['total_item'] = $this->model_catalog_seller->getTotalSellerProducts();
        $data['seller_plan_item'] = $this->model_catalog_seller->getSellerPaymentmode();
			if ($this->session->data['session_market_id'] == 3) {
				 $data['action'] = $this->url->link('saccount/extension/addproduct', '&product_id=' . $this->request->get['product_id'] . $url, 'SSL');
			}else{
            $data['action'] = $this->url->link('saccount/extension/update', '&product_id=' . $this->request->get['product_id'] . '&market_id=' . $this->session->data['session_market_id']. $url, 'SSL');
			}
        }
		
		 $data['action_new'] = $this->url->link('saccount/extension/add', $url, 'SSL');

        $data['cancel'] = $this->url->link('product/seller', 'seller_id='.$this->seller->getId(), 'SSL');
        $data['delete'] = '';
		
        if (isset($this->request->get['product_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
            $product_info = $this->model_saccount_product->getProduct($this->request->get['product_id'], $this->seller->getId());
            $data['product_filters'] = $this->model_saccount_additem->getProductFilters($this->request->get['product_id']);
            $data['heading_title1'] = $this->language->get('Edit Product');
			$data['delete'] = $this->url->link('saccount/extension/delete', '&selected='.$this->request->get['product_id'], 'SSL');
        }

        $this->load->model('localisation/language');

        $data['product_attributes'] = array();
        $data['languages'] = $this->model_localisation_language->getLanguages();

        if (isset($this->request->post['product_description'])) {
            $data['product_description'] = $this->request->post['product_description'];
        } elseif (isset($this->request->get['product_id'])) {
            $data['product_description'] = $this->model_saccount_product->getProductDescriptions($this->request->get['product_id']);
			$data['fund_v']=$product_info['is_fund'];
        } else {
            $data['product_description'] = array();
			$data['fund_v']=0;
        }
//echo "<pre>";print_r($product_info);echo "</pre>";

        /*         * NEW ADDED CODE* */

        if (isset($this->request->post['sku'])) {
            $data['sku'] = $this->request->post['sku'];
        } elseif (!empty($product_info)) {
            $data['sku'] = $product_info['sku'];
        } else {
            $data['sku'] = '';
        }


        if (isset($this->request->post['weight'])) {
            $data['weight'] = $this->request->post['weight'];
        } elseif (!empty($product_info)) {
            $data['weight'] = $product_info['weight'];
        } else {
            $data['weight'] = '';
        }

        $this->load->model('saccount/weight_class');

        $data['weight_classes'] = $this->model_saccount_weight_class->getWeightClasses();

        if (isset($this->request->post['weight_class_id'])) {
            $data['weight_class_id'] = $this->request->post['weight_class_id'];
        } elseif (!empty($product_info)) {
            $data['weight_class_id'] = $product_info['weight_class_id'];
        } else {
            $data['weight_class_id'] = $this->config->get('config_weight_class_id');
        }

        if (isset($this->request->post['length'])) {
            $data['length'] = $this->request->post['length'];
        } elseif (!empty($product_info)) {
            $data['length'] = $product_info['length'];
        } else {
            $data['length'] = '';
        }

        if (isset($this->request->post['width'])) {
            $data['width'] = $this->request->post['width'];
        } elseif (!empty($product_info)) {
            $data['width'] = $product_info['width'];
        } else {
            $data['width'] = '';
        }

        if (isset($this->request->post['height'])) {
            $data['height'] = $this->request->post['height'];
        } elseif (!empty($product_info)) {
            $data['height'] = $product_info['height'];
        } else {
            $data['height'] = '';
        }

        if (isset($this->request->post['data']['shipping_preference'])) {
            $data['shipping_preference'] = $this->request->post['data']['shipping_preference'];
        } elseif ($this->seller->getShippingPreference()) {
            $data['shipping_preference'] = $this->seller->getShippingPreference();
        } else {
            $data['shipping_preference'] = 2;
        }

        $this->load->model('saccount/length_class');

        $data['length_classes'] = $this->model_saccount_length_class->getLengthClasses();

        if (isset($this->request->post['length_class_id'])) {
            $data['length_class_id'] = $this->request->post['length_class_id'];
        } elseif (!empty($product_info)) {
            $data['length_class_id'] = $product_info['length_class_id'];
        } else {
            $data['length_class_id'] = $this->config->get('config_length_class_id');
        }


        $this->load->model('saccount/manufacturer');

        $data['manufacturers'] = $this->model_saccount_manufacturer->getManufacturers();

        if (isset($this->request->post['manufacturer_id'])) {
            $data['manufacturer_id'] = $this->request->post['manufacturer_id'];
        } elseif (!empty($product_info)) {
            $data['manufacturer_id'] = $product_info['manufacturer_id'];
        } else {
            $data['manufacturer_id'] = 0;
        }

        if (isset($this->request->post['manufacturer'])) {
            $data['manufacturer'] = $this->request->post['manufacturer'];
        } elseif (!empty($product_info)) {
            $manufacturer_info = $this->model_saccount_manufacturer->getManufacturer($product_info['manufacturer_id']);

            if ($manufacturer_info) {
                $data['manufacturer'] = $manufacturer_info['name'];
            } else {
                $data['manufacturer'] = '';
            }
        } else {
            $data['manufacturer'] = '';
        }


        if (isset($this->request->post['product_discount'])) {
            $data['product_discounts'] = $this->request->post['product_discount'];
        } elseif (isset($this->request->get['product_id'])) {
            $data['product_discounts'] = $this->model_saccount_product->getProductDiscounts($this->request->get['product_id']);
        } else {
            $data['product_discounts'] = array();
        }



        if (isset($this->request->post['product_special'])) {
            $data['product_specials'] = $this->request->post['product_special'];
        } elseif (isset($this->request->get['product_id'])) {
            $data['product_specials'] = $this->model_saccount_product->getProductSpecials($this->request->get['product_id']);
        } else {
            $data['product_specials'] = array();
        }

        $this->load->model('saccount/customer_group');

        $data['customer_groups'] = $this->model_saccount_customer_group->getCustomerGroups();



        /*         * END OF NEW ADDED CODE* */


        if (isset($this->request->post['productimage'])) {
            $data['productimage'] = $this->request->post['productimage'];
        } elseif (!empty($product_info)) {
            $image = explode('/', $product_info['image']);
			
            $data['productimage'] = 'product/'.array_pop($image);
        } else {
            $data['productimage'] = '';
        }
		
		//echo  $data['productimage'];

        if (isset($this->request->post['productvideo'])) {
            $data['productvideo'] = $this->request->post['productvideo'];
        } elseif (!empty($product_info)) {
            $video = explode('/', $product_info['video']);
            $data['productvideo'] = 'video/'.array_pop($video);
        } else {
            $data['productvideo'] = '';
        }

        $this->load->model('tool/image');
        $this->load->model('saccount/seller');


        $foldername = $this->model_saccount_seller->getfoldername($this->seller->getId());

        $data['foldername'] = $foldername;
		
		//$this->load->model('catalog/seller');
		
		//$seller_info = $this->model_catalog_seller->getSeller($seller_id);		
		$data['seller_id']= $this->seller->getId();
		$data['folder_name'] = $foldername;


        if (isset($this->request->post['productimage'])) {
            $data['thumb'] = "image/" . $foldername ."/". $this->request->post['productimage'];
        } elseif (!empty($product_info) && $product_info['image'] && file_exists(DIR_IMAGE . $product_info['image'])) {
            $data['thumb'] = $this->model_tool_image->resize($product_info['image'], 100, 100);
        } else {
            $data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
        }

        if (isset($this->request->post['license'])) {
            $data['license'] = $this->request->post['license'];
        } elseif (!empty($product_info)) {
            if ($product_info['price'] > 0) {
                $data['license'] = 1;
            }
        } else {
            $data['license'] = 0;
        }
	
		

        if (isset($this->request->post['price'])) {
            $data['price'] = $this->request->post['price'];
        } elseif (!empty($product_info)) {
            $data['price'] = $product_info['price'];
        } else {
            $data['price'] = '';
        }
		
		

        if (isset($this->request->post['model'])) {
            $data['model'] = $this->request->post['model'];
        } elseif (!empty($product_info)) {
            $data['model'] = $product_info['model'];
        } else {
            $data['model'] = '';
        }

        if (isset($this->request->post['documentation'])) {
            $data['documentation'] = $this->request->post['documentation'];
        } elseif (!empty($product_info)) {
            $data['documentation'] = $product_info['documentation'];
        } else {
            $data['documentation'] = '';
        }

        if (isset($this->request->post['date_available'])) {
            $data['date_available'] = $this->request->post['date_available'];
        } elseif (!empty($product_info)) {
            $data['date_available'] = date('Y-m-d', strtotime($product_info['date_available']));
        } else {
            $data['date_available'] = date('Y-m-d', time() - 86400);
        }

        if (isset($this->request->post['quantity'])) {
            $data['quantity'] = $this->request->post['quantity'];
        } elseif (!empty($product_info)) {
            $data['quantity'] = $product_info['quantity'];
        } else {
            $data['quantity'] = 1;
        }

        if (isset($this->request->post['minimum'])) {
            $data['minimum'] = $this->request->post['minimum'];
        } elseif (!empty($product_info)) {
            $data['minimum'] = $product_info['minimum'];
        } else {
            $data['minimum'] = 1;
        }

        if (isset($this->request->post['subtract'])) {
            $data['subtract'] = $this->request->post['subtract'];
        } elseif (!empty($product_info)) {
            $data['subtract'] = $product_info['subtract'];
        } else {
            $data['subtract'] = 0;
        }

        if (isset($this->request->post['sort_order'])) {
            $data['sort_order'] = $this->request->post['sort_order'];
        } elseif (!empty($product_info)) {
            $data['sort_order'] = $product_info['sort_order'];
        } else {
            $data['sort_order'] = 1;
        }




        $this->load->model('saccount/stock_status');

        $data['stock_statuses'] = $this->model_saccount_stock_status->getStockStatuses();

        if (isset($this->request->post['stock_status_id'])) {
            $data['stock_status_id'] = $this->request->post['stock_status_id'];
        } elseif (!empty($product_info)) {
            $data['stock_status_id'] = $product_info['stock_status_id'];
        } else {
            $data['stock_status_id'] = $this->config->get('config_stock_status_id');
        }

        if (isset($this->request->post['status'])) {
            $data['status'] = $this->request->post['status'];
        } elseif (!empty($product_info)) {
            $data['status'] = $product_info['status'];
        } else {
            $data['status'] = 1;
        }

        $this->load->model('saccount/product');

        if (isset($this->request->post['product_option'])) {
            $product_options = $this->request->post['product_option'];
        } elseif (isset($this->request->get['product_id'])) {
            $product_options = $this->model_saccount_product->getProductOptions($this->request->get['product_id']);
        } else {
            $product_options = array();
        }

        $data['product_options'] = array();

        foreach ($product_options as $product_option) {
            $product_option_value_data = array();

            if (isset($product_option['product_option_value'])) {
                foreach ($product_option['product_option_value'] as $product_option_value) {
                    $product_option_value_data[] = array(
                        'product_option_value_id' => $product_option_value['product_option_value_id'],
                        'option_value_id' => $product_option_value['option_value_id'],
                        'quantity' => $product_option_value['quantity'],
                        'subtract' => $product_option_value['subtract'],
                        'price' => $product_option_value['price'],
                        'price_prefix' => $product_option_value['price_prefix'],
                        'points' => $product_option_value['points'],
                        'points_prefix' => $product_option_value['points_prefix'],
                        'weight' => $product_option_value['weight'],
                        'weight_prefix' => $product_option_value['weight_prefix']
                    );
                }
            }

            $data['product_options'][] = array(
                'product_option_id' => $product_option['product_option_id'],
                'product_option_value' => $product_option_value_data,
                'option_id' => $product_option['option_id'],
                'name' => $product_option['name'],
                'type' => $product_option['type'],
                'value' => isset($product_option['value']) ? $product_option['value'] : '',
                'required' => $product_option['required']
            );
        }

        $data['option_values'] = array();

        foreach ($product_options as $product_option) {
            if ($product_option['type'] == 'select' || $product_option['type'] == 'radio' || $product_option['type'] == 'checkbox' || $product_option['type'] == 'image') {
                if (!isset($data['option_values'][$product_option['option_id']])) {
                    $data['option_values'][$product_option['option_id']] = $this->model_saccount_product->getOptionValues($product_option['option_id']);
                }
            }
        }

        if (isset($this->request->post['product_image'])) {
            $product_images = $this->request->post['product_image'];
        } elseif (isset($this->request->get['product_id'])) {
            $product_images = $this->model_saccount_product->getProductImages($this->request->get['product_id']);
        } else {
            $product_images = array();
        }

        $productimages = array();

        foreach ($product_images as $product_image) {
            if ($product_image['image'] && file_exists(DIR_IMAGE . $product_image['image'])) {
                $image = $product_image['image'];
            } else {
                $image = 'no_image.png';
            }
            $image = explode('/', $image);
            $image = array_pop($image);
            ;
            $productimages[] = array(
                'imagename' => 'product/'.$image,
                'imagetext' => $product_image['name'],
            );
        }

        if (isset($this->request->post['product_imagename'])) {
            $data['product_images'] = $this->request->post['product_imagename'];
        } elseif (isset($this->request->get['product_id'])) {
            $data['product_images'] = $productimages;
        } else {
            $data['product_images'] = array();
        }

        $data['no_image'] = $this->model_tool_image->resize('camera icon.png', 100, 100);

        $this->load->model('saccount/download');




        if (isset($this->request->post['product_download'])) {
            $product_downloads = $this->request->post['product_download'];
        } elseif (isset($this->request->get['product_id'])) {
            $product_downloads = $this->model_saccount_product->getProductDownloads($this->request->get['product_id']);
        } else {
            $product_downloads = array();
        }

        $data['product_downloads'] = array();

        foreach ($product_downloads as $download_id) {
            $download_info = $this->model_saccount_download->getDownload($download_id);

            if ($download_info) {
                $data['product_downloads'][] = array(
                    'download_id' => $download_info['download_id'],
                    'name' => $download_info['name']
                );
            }
        }


        $this->load->model('saccount/category');
        $this->load->model('catalog/category');

        // Categories
        $this->load->model('catalog/category');

        if (isset($this->request->post['product_category'])) {
            $categories = $this->request->post['product_category'];
        } elseif (isset($this->request->get['product_id'])) {
            $categories = $this->model_saccount_product->getProductCategories($this->request->get['product_id']);
        } else {
            $categories = array();
        }

        $data['selected_product_categories'] = $categories;
        $data['product_categories'] = array();
		
		 

        foreach ($categories as $category_id) {
            $category_info = $this->model_saccount_category->getCategory1($category_id);

            if ($category_info) {
                $data['product_categories'][] = array(
                    'category_id' => $category_info['category_id'],
                    'name' => ($category_info['path']) ? $category_info['path'] . ' &gt; ' . $category_info['name'] : $category_info['name']
                );
            }
        }


        $data['categories'] = $this->model_saccount_category->getApproveCategories(0, $this->seller->getId());
        $config_product_categories = $this->config->get('config_product_category');
        if ($config_product_categories) {
            foreach ($config_product_categories as $config_product_category) {
                $data['categories'][] = $this->model_saccount_category->getCategory1($config_product_category);
            }
        }



        $data['column_left'] = $this->load->controller('common/column_left');
        $data['column_right'] = $this->load->controller('common/column_right');
        $data['content_top'] = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/header');
        $data['seller_right'] = $this->load->controller('product/seller_right');
        $data['seller_profile'] = $this->load->controller('product/seller_profile');
        $data['seller_billboard'] = $this->load->controller('product/seller_billboard');
        $data['seller_marketplace'] = $this->load->controller('product/seller_marketplace');
        if($use_template == '') {
            $use_template = 'product_form';
        }
        if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/saccount/'.$use_template.'.tpl')) {
            $this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/saccount/'.$use_template.'.tpl', $data));
        } else {
            $this->response->setOutput($this->load->view('default/template/saccount/'.$use_template.'.tpl', $data));
        }
    }

    public function upload() {
        $this->language->load('saccount/extension');
        $json = array();

        if (!empty($this->request->files['file']['name'])) {
            $filename = basename(html_entity_decode($this->request->files['file']['name'], ENT_QUOTES, 'UTF-8'));

            if ((strlen($filename) < 3) || (strlen($filename) > 128)) {
                $json['error'] = $this->language->get('error_filename');
            }

            $allowed = array();

           // $filetypes = explode("\n", $this->config->get('config_file_ext_allowed'));

            //foreach ($filetypes as $filetype) {
                //$allowed[] = trim($filetype);
          //  }

            //if (!in_array(substr(strrchr($filename, '.'), 1), $allowed)) {
                //$json['error'] = $this->language->get('error_filetype');
            //}

            if ($this->request->files['file']['error'] != UPLOAD_ERR_OK) {
                $json['error'] = $this->language->get('error_upload_' . $this->request->files['file']['error']);
            }
        } else {
            $json['error'] = $this->language->get('error_upload');
        }

        if (!$json) {
            if (is_uploaded_file($this->request->files['file']['tmp_name']) && file_exists($this->request->files['file']['tmp_name'])) {
                //$file = basename($filename) . '.' . md5(rand());
                $file = md5(rand()).'_'.basename($filename);

                // Hide the uploaded file name so people can not link to it directly.
                $json['file'] = $file;
				$filen = explode(".", $file);
				$ext = end($filen);

                $this->load->model('saccount/seller');

                $foldername = $this->model_saccount_seller->getfoldername($this->seller->getId());

                $json['foldername'] = $foldername . '/product/';
				
				//$exif =  @exif_read_data($this->request->files['file']['tmp_name']);
               
                move_uploaded_file($this->request->files['file']['tmp_name'], DIR_IMAGE . $foldername . '/product/' . $file);
				//$this->image_fix_orientation(DIR_IMAGE . $foldername . '/product/' . $file,$file);
				if($ext=="JPG" || $ext=="JPEG" || $ext=="jpg" || $ext=="jpeg"){
				$exif = exif_read_data(DIR_IMAGE . $foldername . '/product/' . $file);
				 if (!empty($exif['Orientation'])) {
					   $image = imagecreatefromjpeg(DIR_IMAGE . $foldername . '/product/' . $file);
                   switch ($exif['Orientation']) {
							case 3:
								$image = imagerotate($image, 180, 0);
								break;

							case 6:
							
								$image = imagerotate($image, -90, 0);
								break;

							case 8:
								$image = imagerotate($image, 90, 0);
								break;
						}
						
						imagejpeg($image, DIR_IMAGE . $foldername . '/product/' . $file, 90);
					}
				}
            }

            $json['success'] = $this->language->get('text_upload');
        }

        $this->response->setOutput(json_encode($json));
    }
	
	public function image_fix_orientation($image,$fname) {
    if (method_exists($image, 'getImageProperty')) {
        $orientation = $image->getImageProperty('exif:Orientation');
    } else {
        $filename = $fname;

        if (empty($filename)) {
            $filename = 'data://image/jpeg;base64,' . base64_encode($image->getImageBlob());
        }

        $exif = exif_read_data($filename);
        $orientation = isset($exif['Orientation']) ? $exif['Orientation'] : null;
    }

    if (!empty($orientation)) {
        switch ($orientation) {
            case 3:
                $image->rotateImage('#000000', 180);
                break;

            case 6:
                $image->rotateImage('#000000', 90);
                break;

            case 8:
                $image->rotateImage('#000000', -90);
                break;
        }
    }
}

    public function videoupload() {
        $this->language->load('saccount/extension');
        $json = array();

        if (!empty($this->request->files['file']['name'])) {
            $filename = basename(html_entity_decode($this->request->files['file']['name'], ENT_QUOTES, 'UTF-8'));

            if ((strlen($filename) < 3) || (strlen($filename) > 128)) {
                $json['error'] = $this->language->get('error_filename');
            }

            $allowed = array();

            $filetypes = explode("\n", $this->config->get('config_file_ext_allowed'));

           // foreach ($filetypes as $filetype) {
              //  $allowed[] = trim($filetype);
            //}

           // if (!in_array(substr(strrchr($filename, '.'), 1), $allowed)) {
                //$json['error'] = $this->language->get('error_filetype');
            //}

            if ($this->request->files['file']['error'] != UPLOAD_ERR_OK) {
                $json['error'] = $this->language->get('error_upload_' . $this->request->files['file']['error']);
            }
        } else {
            $json['error'] = $this->language->get('error_upload');
        }

        if (!$json) {
            if (is_uploaded_file($this->request->files['file']['tmp_name']) && file_exists($this->request->files['file']['tmp_name'])) {
                //$file = basename($filename) . '.' . md5(rand());
                $file = basename($filename);

                // Hide the uploaded file name so people can not link to it directly.
                $json['file'] = $file;

                $this->load->model('saccount/seller');

                $foldername = $this->model_saccount_seller->getfoldername($this->seller->getId());

                $json['foldername'] = $foldername . '/video/';

                move_uploaded_file($this->request->files['file']['tmp_name'], DIR_IMAGE . $foldername . '/video/' . $file);
            }

            $json['success'] = $this->language->get('text_upload');
        }

        $this->response->setOutput(json_encode($json));
    }

    public function download() {
        $this->language->load('saccount/extension');


        $json = array();

        if (!empty($this->request->files['file']['name'])) {
            $filename = basename(html_entity_decode($this->request->files['file']['name'], ENT_QUOTES, 'UTF-8'));

            if ((strlen($filename) < 3) || (strlen($filename) > 128)) {
                $json['error'] = $this->language->get('error_filename');
            }

            $allowed = array();

            $filetypes = explode(',', 'zip');

            foreach ($filetypes as $filetype) {
                $allowed[] = trim($filetype);
            }

            if (!in_array(substr(strrchr($filename, '.'), 1), $allowed)) {
                $json['error'] = $this->language->get('error_filetype1');
            }

            if ($this->request->files['file']['error'] != UPLOAD_ERR_OK) {
                $json['error'] = $this->language->get('error_upload_' . $this->request->files['file']['error']);
            }
        } else {
            $json['error'] = $this->language->get('error_upload');
        }

        if (!$json) {
            $this->load->model('saccount/download');
            $data = array();
            if (is_uploaded_file($this->request->files['file']['tmp_name']) && file_exists($this->request->files['file']['tmp_name'])) {
                $file = basename($filename) . '.' . md5(rand());
                // Hide the uploaded file name so people can not link to it directly.
                $json['file'] = basename($filename);
                $json['download_id'] = $file;
                move_uploaded_file($this->request->files['file']['tmp_name'], DIR_DOWNLOAD . $file);
                if (file_exists(DIR_DOWNLOAD . $file)) {
                    $data['download'] = $file;
                    $data['mask'] = $this->request->files['file']['name'];
                    $download_id = $this->model_saccount_download->addDownload($data);
                    $json['download_id'] = $download_id;
                }
            }

            $json['success'] = $this->language->get('text_upload');
        }

        $this->response->setOutput(json_encode($json));
    }

    private function validateForm() {

        foreach ($this->request->post['product_description'] as $language_id => $value) {
            if ((utf8_strlen($value['name']) < 1) || (utf8_strlen($value['name']) > 255)) {
                $this->error['name'][$language_id] = $this->language->get('error_name');
            }
        }



        /* if ((utf8_strlen($this->request->post['model']) < 3) || (utf8_strlen($this->request->post['model']) > 25)) {
          $this->error['model'] = $this->language->get('error_model');
          } */

        /* if(isset($this->request->post['download_imagename'])){
          foreach ($this->request->post['download_imagename'] as $value) {
          if(empty($value['downloadname'])){
          $this->error['warning'] = $this->language->get('error_download1');
          }
          }
          }


          if (empty($this->session->data['captcha']) || ($this->session->data['captcha'] != $this->request->post['captcha'])) {
          $this->error['captcha'] = $this->language->get('error_captcha');
          } */

        $this->load->model('catalog/seller'); $this->load->model('saccount/product');
        $total_item = $this->model_catalog_seller->getTotalSellerProducts();
        $seller_plan_item = $this->model_catalog_seller->getSellerPaymentmode();
		$sub_status = $this->model_saccount_product->checkSellerPackage($this->seller->getId());

        if ($sub_status == 0) {
		}else{
			if ($total_item > $seller_plan_item) {
				$this->error['maximum_limit'] = "You can't add item more than requested limit.";
			}
		}
		if(isset($this->request->post['data']['shipping_preference']) && $this->request->post['data']['shipping_preference']==2){
			
			if (isset($this->request->post['length']) && $this->request->post['length']<=0) {
				 $this->error['lname'][$language_id] = "Please provide the length of item.";
			}
			
			if (isset($this->request->post['width']) && $this->request->post['width']<=0) {
				 $this->error['wname'][$language_id] = "Please provide the width of item.";
			}
			
			if (isset($this->request->post['height']) && $this->request->post['height']<=0) {
				 $this->error['hname'][$language_id] = "Please provide the height of item.";
			}
			if (isset($this->request->post['weight']) && $this->request->post['weight']<=0) {
				 $this->error['wename'][$language_id] = "Please provide the weight of item.";
			}
			
		}

        if ($this->error && !isset($this->error['warning'])) {
            $this->error['warning'] = $this->language->get('error_warning');
        }
		
		//print_r($this->error);

        if (!$this->error) {
            return true;
        } else {
            return false;
        }
    }

    private function validateUpdateForm() {

        foreach ($this->request->post['product_description'] as $language_id => $value) {
            if ((utf8_strlen($value['name']) < 1) || (utf8_strlen($value['name']) > 255)) {
                $this->error['name'][$language_id] = $this->language->get('error_name');
            }
        }
		
		if(isset($this->request->post['data']['shipping_preference']) && $this->request->post['data']['shipping_preference']==2){
			
			if (isset($this->request->post['length']) && $this->request->post['length']<=0) {
				 $this->error['lname'][$language_id] = "Please provide the length of item.";
			}
			
			if (isset($this->request->post['width']) && $this->request->post['width']<=0) {
				 $this->error['wname'][$language_id] = "Please provide the width of item.";
			}
			
			if (isset($this->request->post['height']) && $this->request->post['height']<=0) {
				 $this->error['hname'][$language_id] = "Please provide the height of item.";
			}
			if (isset($this->request->post['weight']) && $this->request->post['weight']<=0) {
				 $this->error['wename'][$language_id] = "Please provide the weight of item.";
			}
			
		}



        /* if ((utf8_strlen($this->request->post['model']) < 3) || (utf8_strlen($this->request->post['model']) > 25)) {
          $this->error['model'] = $this->language->get('error_model');
          } */

        /* if(isset($this->request->post['download_imagename'])){
          foreach ($this->request->post['download_imagename'] as $value) {
          if(empty($value['downloadname'])){
          $this->error['warning'] = $this->language->get('error_download1');
          }
          }
          }


          if (empty($this->session->data['captcha']) || ($this->session->data['captcha'] != $this->request->post['captcha'])) {
          $this->error['captcha'] = $this->language->get('error_captcha');
          } */



        if ($this->error && !isset($this->error['warning'])) {
            $this->error['warning'] = $this->language->get('error_warning');
        }

        if (!$this->error) {
            return true;
        } else {
            return false;
        }
    }

    private function validateDelete() {

        if (!$this->error) {
            return true;
        } else {
            return false;
        }
    }

    private function validateCopy() {

        if (!$this->error) {
            return true;
        } else {
            return false;
        }
    }

    public function manuautocomplete() {
        $json = array();

        if (isset($this->request->get['filter_name'])) {
            $this->load->model('saccount/manufacturer');

            $filter_data = array(
                'filter_name' => $this->request->get['filter_name'],
                'start' => 0,
                'limit' => 5
            );

            $results = $this->model_saccount_manufacturer->getManufacturers($filter_data);

            foreach ($results as $result) {
                $json[] = array(
                    'manufacturer_id' => $result['manufacturer_id'],
                    'name' => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8'))
                );
            }
        }

        $sort_order = array();

        foreach ($json as $key => $value) {
            $sort_order[$key] = $value['name'];
        }

        array_multisort($sort_order, SORT_ASC, $json);

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function autocomplete() {
        if (isset($this->request->get['filter_name1']) || isset($this->request->get['filter_model'])) {
            $this->load->model('saccount/product');
            $this->load->model('saccount/option');

            if (isset($this->request->get['filter_name1'])) {
                $filter_name1 = $this->request->get['filter_name1'];
            } else {
                $filter_name1 = '';
            }

            if (isset($this->request->get['filter_model'])) {
                $filter_model = $this->request->get['filter_model'];
            } else {
                $filter_model = '';
            }

            if (isset($this->request->get['limit'])) {
                $limit = $this->request->get['limit'];
            } else {
                $limit = 5;
            }

            $filter_data = array(
                'filter_name1' => $filter_name1,
                'filter_model' => $filter_model,
                'start' => 0,
                'limit' => $limit
            );
            $seller = $this->seller->getId();


            $results = $this->model_saccount_product->getProducts($filter_data, $seller);

            foreach ($results as $result) {
                $option_data = array();

                $product_options = $this->model_saccount_product->getProductOptions($result['product_id'], $this->seller->getId());

                foreach ($product_options as $product_option) {

                    $option_info = $this->model_saccount_option->getOption($product_option['option_id'], $this->seller->getId());

                    if ($option_info) {
                        $product_option_value_data = array();

                        foreach ($product_option['product_option_value'] as $product_option_value) {
                            $option_value_info = $this->model_saccount_option->getOptionValue($product_option_value['option_value_id']);

                            if ($option_value_info) {
                                $product_option_value_data[] = array(
                                    'product_option_value_id' => $product_option_value['product_option_value_id'],
                                    'option_value_id' => $product_option_value['option_value_id'],
                                    'name' => $option_value_info['name'],
                                    'price' => (float) $product_option_value['price'] ? $this->currency->format($product_option_value['price'], $this->config->get('config_currency')) : false,
                                    'price_prefix' => $product_option_value['price_prefix']
                                );
                            }
                        }

                        $option_data[] = array(
                            'product_option_id' => $product_option['product_option_id'],
                            'product_option_value' => $product_option_value_data,
                            'option_id' => $product_option['option_id'],
                            'name' => $option_info['name'],
                            'type' => $option_info['type'],
                            'value' => $product_option['value'],
                            'required' => $product_option['required']
                        );
                    }
                }

                $json[] = array(
                    'product_id' => $result['product_id'],
                    'name' => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
                    'model' => $result['model'],
                    'option' => $option_data,
                    'price' => $result['price']
                );
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function add() {

        if (!$this->seller->isLogged()) {
            $this->session->data['redirect'] = $this->url->link('saccount/extension/add', '', 'SSL');

            $this->response->redirect($this->url->link('common/landing', '', 'SSL'));
        }

        $data['session_market_id'] = $this->session->data['session_market_id'];
        //exit;
        $this->load->language('saccount/add');

        $this->document->setTitle($this->language->get('heading_title1'));

        $this->load->model('saccount/product');
		$this->load->model('saccount/seller');
		$this->load->model('saccount/additem');
		 
		 $data['categories_f'] = $this->model_saccount_additem->getFundcategory();		
		
		$seller_info = $this->model_saccount_seller->getSeller($this->seller->getId());
		
		if ($this->request->post['aboutus']) {
			$this->model_saccount_seller->editSellerAboutUs($this->request->post['aboutus']);
		}
		
		if (isset($this->request->post['aboutus'])) {
    		$data['aboutus'] = $this->request->post['aboutus'];
		}elseif (isset($seller_info)) {
			$data['aboutus'] = $seller_info['aboutus'];
		}   else {
			$data['aboutus'] = '';
		}


        if (($this->request->server['REQUEST_METHOD'] == 'POST')) {

            $this->request->post['shipping'] = 0;

            // check if seller has active subscription or not.
            $sub_status = $this->model_saccount_product->checkSellerPackage($this->seller->getId());

            if ($sub_status == 0) {
                // seller is not subscribed. modify the status
                // auto approve product
                $this->request->post['approve'] = 3;
                $this->request->post['status'] = 3;
            } else {
                // seller is subscribed.
                // auto approve product
                $this->request->post['approve'] = 1;
                $this->request->post['status'] = 1;
            }
			
			/* Remove special characters from fundtotal | SynapaseIndia - 1721 */
			if($this->request->post['fundtotal'] && $this->request->post['fundtotal'] != '0.00'){
				$fundtotal = str_replace('$', '', $this->request->post['fundtotal']);
				$fundtotal = str_replace(',', '', trim($fundtotal));
			} else {
				$fundtotal = 0;
			}

            if (!empty($fundtotal)) {
                $this->model_saccount_product->setSellerFundTotal($fundtotal);
            }
			
			 
            // remove all older products and then add new.
            $seller_products = $this->model_saccount_product->getSellerFundProducts();
            foreach ($seller_products as $seller_product) {
                $this->model_saccount_product->deleteProduct($seller_product);
				
				//$this->db->query("DELETE FROM " . DB_PREFIX . "product_to_category WHERE product_id = '" . (int)$seller_product . "'");
            }
            if (!empty($this->request->post['funding'])) {
                foreach ($this->request->post['funding'] as $product) {
                    $this->model_saccount_product->copyProduct($product, $this->request->post);
                }
            }

            $this->session->data['success'] = $this->language->get('text_success');

            $url = '';

            if (isset($this->request->get['filter_name1'])) {
                $url .= '&filter_name1=' . $this->request->get['filter_name1'];
            }

            if (isset($this->request->get['filter_model'])) {
                $url .= '&filter_model=' . $this->request->get['filter_model'];
            }

            if (isset($this->request->get['filter_price'])) {
                $url .= '&filter_price=' . $this->request->get['filter_price'];
            }

            if (isset($this->request->get['filter_quantity'])) {
                $url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
            }

            if (isset($this->request->get['sort'])) {
                $url .= '&sort=' . $this->request->get['sort'];
            }

            if (isset($this->request->get['order'])) {
                $url .= '&order=' . $this->request->get['order'];
            }

            if (isset($this->request->get['page'])) {
                $url .= '&page=' . $this->request->get['page'];
            }

            if ($sub_status == 0) {
				if($data['session_market_id']==2){
				 $this->response->redirect($this->url->link('saccount/funding&market_id='.$data['session_market_id'], $url, 'SSL'));
				}else{
                // seller is not subscribed. redirect to subscribe page
                $this->response->redirect($this->url->link('saccount/subscribe&market_id='.$data['session_market_id'], $url, 'SSL'));
				}
            } else {
                // seller is subscribed.
                $this->response->redirect($this->url->link('product/seller&market_id='.$data['session_market_id'],'seller_id='.$this->seller->getId(), 'SSL'));
            }
        }

        $this->getForm('product_form');
    }

    public function addproduct() {

        if (!$this->seller->isLogged()) {
            $this->session->data['redirect'] = $this->url->link('saccount/extension/addproduct', '', 'SSL');

            $this->response->redirect($this->url->link('common/landing', '', 'SSL'));
        }
        $this->load->language('saccount/add');

        $this->document->setTitle($this->language->get('heading_title1'));

        $this->load->model('saccount/product');
		
		$this->load->model('catalog/seller'); $this->load->model('saccount/product');
        $data['total_item'] = $this->model_catalog_seller->getTotalSellerProducts();
        $data['seller_plan_item'] = $this->model_catalog_seller->getSellerPaymentmode();


        if (($this->request->server['REQUEST_METHOD'] == 'POST')) {
			
			

            //$this->request->post['shipping'] = 0;
            $product_filter = array();
            if (!empty($this->request->post['condition'])) {
                array_push($product_filter, $this->request->post['condition']);
            }
            if (!empty($this->request->post['colour'])) {
                $product_filter = array_merge((array) $this->request->post['colour'], (array) $product_filter);
            }
            $this->request->post['product_filter'] = $product_filter;
            if (!empty($this->request->post['data']['shipping_preference'])) {
                if ($this->request->post['data']['shipping_preference'] != 1) {
                    $this->request->post['shipping'] = 1;
                } else {
                    $this->request->post['shipping'] = 0;
                }
            } else {
                $this->request->post['shipping'] = 0;
            }

            // check if seller has active subscription or not.
            $sub_status = $this->model_saccount_product->checkSellerPackage($this->seller->getId());

            if ($sub_status == 0) {
                // seller is not subscribed. modify the status
                // auto approve product
                $this->request->post['approve'] = 3;
                $this->request->post['status'] = 3;
            } else {
                // seller is subscribed.
                // auto approve product
                $this->request->post['approve'] = 1;
                $this->request->post['status'] = 1;
            }

            if (!empty($this->request->post['fundtotal'])) {
                $this->model_saccount_product->setSellerFundTotal($this->request->post['fundtotal']);
            }

            // remove all older products and then add new.
            $seller_products = $this->model_saccount_product->getSellerFundProducts();
            foreach ($seller_products as $seller_product) {
                $this->model_saccount_product->deleteProduct($seller_product);
            }
            if (!empty($this->request->post['funding'])) {
                foreach ($this->request->post['funding'] as $product) {
                    $this->model_saccount_product->copyProduct($product, $this->request->post);
                }
            }
			// For calculating price on behalf of shiping preference
				
			if($this->seller->getShippingPreference()== 2 && (isset($this->request->post['weight']) && isset($this->request->post['length']) && isset($this->request->post['width']) && isset($this->request->post['height']))){
			
			
			$seller_shipping_ser=$this->db->query("Select * FROM " . DB_PREFIX . "seller_shipping where seller_id='".$this->seller->getId()."'");
			if(!empty($seller_shipping_ser)){
				$var_s=json_decode($seller_shipping_ser->row['shipping_service']);
				if($var_s[0]==2){
					
				$service = '03';
		        $ups_price=$this->ups($seller_shipping_ser->row['zipcode'],'03',$this->request->post['weight'],(int)$this->request->post['length'],(int)$this->request->post['width'],(int)$this->request->post['height']);
				}else if($var_s[0]== 1){
					
					$services['fedex']['FEDEXGROUND'] = 'Ground';

					$config = array(
						// Services
						'services' => $services,
						// Weight
						'weight' => (int)$this->request->post['weight'], // Default = 1
						'weight_units' => 'lb', // lb (default), oz, gram, kg
						// Size
						'size_length' => (int)$this->request->post['length'], // Default = 8
						'size_width' => (int)$this->request->post['width'], // Default = 4
						'size_height' => (int)$this->request->post['height'], // Default = 2
						'size_units' => 'in', // in (default), feet, cm
						// From
						'from_zip' => 97210,
						'from_state' => "OR", // Only Required for FedEx
						'from_country' => "US",
						// To
						'to_zip' => $seller_shipping_ser->row['zipcode'],
						'to_state' => "MN", // Only Required for FedEx
						'to_country' => "US",
						// Service Logins
						'ups_access' => '', // UPS Access License Key
						'ups_user' => '', // UPS Username  
						'ups_pass' => '', // UPS Password  
						'ups_account' => '', // UPS Account Number
						'usps_user' => '', // USPS User Name
						/* 'fedex_account' => '604501202', // FedEX Account Number coolteam
						  'fedex_meter' => '118719802' // FedEx Meter Number coolteam */
						'fedex_account' => '510087542', // client testing account
						'fedex_meter' => '118719771'  // client testing meter
					);
                  
				 $ship = new FedexAPI($config);
// Get Rates
               $rates = $ship->calculate();print_r($rates);
			    $fed_price=$rates['fedex']['FEDEXGROUND'];

				}else if($var_s[0]== 3){
					 $usps_price=$this->USPSParcelRate($this->request->post['weight'],$seller_shipping_ser->row['zipcode']);
				}
				
			}
		   // echo $ups_price; die;
		}
		
		if($this->request->post['price'] && $this->request->post['price'] != '0.00'){
				$this->request->post['price'] = str_replace('$', '', $this->request->post['price']);
				$this->request->post['price'] = str_replace(',', '', trim($this->request->post['price']));
			} else {
				$this->request->post['price'] = 0;
			}
		
		if(isset($ups_price) && !empty($ups_price)){
			$this->request->post['price']=$this->request->post['price']+$ups_price;
		}
		
		if(isset($fed_price) && !empty($fed_price)){
			$this->request->post['price']=$this->request->post['price']+$fed_price;
		}
		
		
		if(isset($usps_price) && !empty($usps_price)){
			$this->request->post['price']=$this->request->post['price']+$usps_price;
		}
		
			if(!isset($this->request->get['product_id']) && $this->request->post['product_description'][1]['name']){
               $this->model_saccount_product->addProduct($this->request->post);
			}else{
				$this->model_saccount_product->editProduct($this->request->get['product_id'], $this->request->post);
			}
            $this->session->data['success'] = $this->language->get('text_success');

            $url = '';

            if (isset($this->request->get['filter_name1'])) {
                $url .= '&filter_name1=' . $this->request->get['filter_name1'];
            }

            if (isset($this->request->get['filter_model'])) {
                $url .= '&filter_model=' . $this->request->get['filter_model'];
            }

            if (isset($this->request->get['filter_price'])) {
                $url .= '&filter_price=' . $this->request->get['filter_price'];
            }

            if (isset($this->request->get['filter_quantity'])) {
                $url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
            }

            if (isset($this->request->get['sort'])) {
                $url .= '&sort=' . $this->request->get['sort'];
            }

            if (isset($this->request->get['order'])) {
                $url .= '&order=' . $this->request->get['order'];
            }

            if (isset($this->request->get['page'])) {
                $url .= '&page=' . $this->request->get['page'];
            }
           if(isset($this->request->get['next_val']) && $this->request->get['next_val']==1){
			  
                $this->response->redirect($this->url->link('saccount/extension/addproduct', $url, 'SSL'));
				
		   }else{
            if ($sub_status == 0) {
                // seller is not subscribed. redirect to subscribe page
                $this->response->redirect($this->url->link('saccount/subscribe', $url, 'SSL'));
            } else {
                // seller is subscribed.
                $this->response->redirect($this->url->link('product/seller', 'seller_id='.$this->seller->getId(), 'SSL'));
            }
		   }
        }

        $this->getForm('product_fundraiser_form');
    }

    public function ups($dest_zip,$service,$weight,$length,$width,$height) {
		error_reporting(0);
   //echo $dest_zip.'>>>>>'.$service.'>>>>>'.$weight.'>>>>>'.$length.'>>>>>'.$width.'>>>>>'.$height;
		$AccessLicenseNumber = '5D08F36A6C9795C5'; // Your license number
		$UserId = 'skadco'; // Username
		$Password = 'Kysg0702sg'; // Password
		$PostalCode = '98004'; // Zipcode you are shipping FROM
		$ShipperNumber = '1441X1'; // Your UPS shipper number


			$data ="<?xml version=\"1.0\"?>
			<AccessRequest xml:lang=\"en-US\">
				<AccessLicenseNumber>$AccessLicenseNumber</AccessLicenseNumber>
				<UserId>$UserId</UserId>
				<Password>$Password</Password>
			</AccessRequest>
			<?xml version=\"1.0\"?>
			<RatingServiceSelectionRequest xml:lang=\"en-US\">
				<Request>
					<TransactionReference>
						<CustomerContext>Bare Bones Rate Request</CustomerContext>
						<XpciVersion>1.0001</XpciVersion>
					</TransactionReference>
					<RequestAction>Rate</RequestAction>
					<RequestOption>Rate</RequestOption>
				</Request>
			<PickupType>
				<Code>01</Code>
			</PickupType>
			<Shipment>
				<Shipper>
					<Address>
						<PostalCode>$PostalCode</PostalCode>
						<CountryCode>US</CountryCode>
					</Address>
				<ShipperNumber>$ShipperNumber</ShipperNumber>
				</Shipper>
				<ShipTo>
					<Address>
						<PostalCode>$dest_zip</PostalCode>
						<CountryCode>US</CountryCode>
					<ResidentialAddressIndicator/>
					</Address>
				</ShipTo>
				<ShipFrom>
					<Address>
						<PostalCode>$PostalCode</PostalCode>
						<CountryCode>US</CountryCode>
					</Address>
				</ShipFrom>
				<Service>
					<Code>$service</Code>
				</Service>
				<Package>
					<PackagingType>
						<Code>02</Code>
					</PackagingType>
					<Dimensions>
						<UnitOfMeasurement>
							<Code>IN</Code>
						</UnitOfMeasurement>
						<Length>$length</Length>
						<Width>$width</Width>
						<Height>$height</Height>
					</Dimensions>
					<PackageWeight>
						<UnitOfMeasurement>
							<Code>LBS</Code>
						</UnitOfMeasurement>
						<Weight>$weight</Weight>
					</PackageWeight>
				</Package>
			</Shipment>
			</RatingServiceSelectionRequest>";
			$ch = curl_init("https://www.ups.com/ups.app/xml/Rate");
			curl_setopt($ch, CURLOPT_HEADER, 1);
			curl_setopt($ch,CURLOPT_POST,1);
			curl_setopt($ch,CURLOPT_TIMEOUT, 60);
			curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
			curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
			$result = curl_exec ($ch);
		
			$data = strstr($result, '<?');
			$xml_parser = xml_parser_create();
			xml_parse_into_struct($xml_parser, $data, $vals, $index);
			xml_parser_free($xml_parser);
			$params = array();
			$level = array();
			foreach ($vals as $xml_elem) {
			 if ($xml_elem['type'] == 'open') {
			if (array_key_exists('attributes',$xml_elem)) {
				 list($level[$xml_elem['level']],$extra) = array_values($xml_elem['attributes']);
			} else {
				 $level[$xml_elem['level']] = $xml_elem['tag'];
			}
			 }
			 if ($xml_elem['type'] == 'complete') {
			$start_level = 1;
			$php_stmt = '$params';
			while($start_level < $xml_elem['level']) {
				 $php_stmt .= '[$level['.$start_level.']]';
				 $start_level++;
			}
			$php_stmt .= '[$xml_elem[\'tag\']] = $xml_elem[\'value\'];';
			eval($php_stmt);
			 }
			}
			curl_close($ch);
			
			return $params['RATINGSERVICESELECTIONRESPONSE']['RATEDSHIPMENT']['TOTALCHARGES']['MONETARYVALUE'];
	}
	
	
	public function USPSParcelRate($weight,$dest_zip) {
       // $weight="2";
		//$dest_zip="97210";
		// This script was written by Mark Sanborn at http://www.marksanborn.net  
		// If this script benefits you are your business please consider a donation  
		// You can donate at http://www.marksanborn.net/donate.  

		// ========== CHANGE THESE VALUES TO MATCH YOUR OWN ===========

		$userName = '328DKACC2662'; // Your USPS Username
		$orig_zip = '98009'; // Zipcode you are shipping FROM

		// =============== DON'T CHANGE BELOW THIS LINE ===============

		$url = "http://Production.ShippingAPIs.com/ShippingAPI.dll";
		$ch = curl_init();

		// set the target url
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_HEADER, 1);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);

		// parameters to post
		curl_setopt($ch, CURLOPT_POST, 1);

		//$data = "API=RateV3&XML=<RateV3Request USERID=\"$userName\"><Package ID=\"1ST\"><Service>PRIORITY</Service><ZipOrigination>$orig_zip</ZipOrigination><ZipDestination>$dest_zip</ZipDestination><Pounds>$weight</Pounds><Ounces>0</Ounces><Size>REGULAR</Size><Machinable>TRUE</Machinable></Package></RateV3Request>";
			$data = "API=RateV4&XML=<RateV4Request USERID=\"$userName\"><Revision>2</Revision><Package ID=\"1ST\"><Service>ALL</Service><ZipOrigination>$orig_zip</ZipOrigination><ZipDestination>$dest_zip</ZipDestination><Pounds>$weight</Pounds>
          <Ounces>0</Ounces>
          <Container />
          <Size>REGULAR</Size>
          <Width>2</Width>
          <Length>1</Length>
          <Height>3</Height>
          <Girth>10</Girth>
          <Machinable>false</Machinable>
       </Package>
    </RateV4Request>";
	

		// send the POST values to USPS
		curl_setopt($ch, CURLOPT_POSTFIELDS,$data);

		$result=curl_exec ($ch);
		$data = strstr($result, '<?');
		// echo '<!-- '. $data. ' -->'; // Uncomment to show XML in comments
		$xml_parser = xml_parser_create();
		xml_parse_into_struct($xml_parser, $data, $vals, $index);
		xml_parser_free($xml_parser);
		$params = array();
		$level = array();
		foreach ($vals as $xml_elem) {
			if ($xml_elem['type'] == 'open') {
				if (array_key_exists('attributes',$xml_elem)) {
					list($level[$xml_elem['level']],$extra) = array_values($xml_elem['attributes']);
				} else {
				$level[$xml_elem['level']] = $xml_elem['tag'];
				}
			}
			if ($xml_elem['type'] == 'complete') {
			$start_level = 1;
			$php_stmt = '$params';
			while($start_level < $xml_elem['level']) {
				$php_stmt .= '[$level['.$start_level.']]';
				$start_level++;
			}
			$php_stmt .= '[$xml_elem[\'tag\']] = $xml_elem[\'value\'];';
			eval($php_stmt);
			}
		}
		curl_close($ch);
		
		// echo '<pre>'; print_r($params); echo'</pre>'; // Uncomment to see xml tags
		//echo $params['RATEV4RESPONSE']['1ST']['1']['RATE'];
	     return isset($params['RATEV4RESPONSE']['1ST']['1']['RATE'])?$params['RATEV4RESPONSE']['1ST']['1']['RATE']:0;
		}

}

?>