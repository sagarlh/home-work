<?php
// Heading 
$_['heading_title']     = 'Email Notifications';

// Text
$_['text_shipping']       = 'Emails';
$_['text_account']       = 'Account';
$_['text_list']       = 'Email List';
$_['text_success']      = 'Success: Your shipping preference has been successfully updated.';

// Entry
$_['entry_pick']   = 'Pick Up';
$_['entry_delivery']   = 'Delivery';
$_['entry_seller']      = 'Seller Delivery Option';

// Error
$_['error_nooption']     = 'Warning: Please select your preference!';
?>