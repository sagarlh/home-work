<?php 
class ControllerProductSellerRight extends Controller {  
	public function index() { 
	
	    $seller_id = $this->seller->getId();		

		$data['seller_group_id'] = $_GET['market_id'];
		$data['mymarket'] = $this->url->link('product/seller&market_id='.$this->session->data['session_market_id'], 'seller_id='.$seller_id, 'SSL');	
		$data['market_list'] = $this->url->link('saccount/market_listing&market_id='.$this->session->data['session_market_id'], '', 'SSL');	
		$data['myprofile'] = $this->url->link('saccount/account&market_id='.$this->session->data['session_market_id'], '', 'SSL');	
		$data['funding'] = $this->url->link('saccount/funding&market_id='.$this->session->data['session_market_id'], '', 'SSL');
		$data['mymarkets'] = $this->url->link('saccount/edit&market_id='.$this->session->data['session_market_id'], '', 'SSL');
		$data['sold_items'] = $this->url->link('saccount/reports/sold&market_id='.$this->session->data['session_market_id'], '', 'SSL');
		$data['shipping_services'] = $this->url->link('saccount/shipping&market_id='.$this->session->data['session_market_id'], '', 'SSL');	
		$data['paypal_email'] = $this->url->link('saccount/address2&market_id='.$this->session->data['session_market_id'], '', 'SSL');	
		$data['orders'] = $this->url->link('saccount/order&market_id='.$this->session->data['session_market_id'], '', 'SSL');	
		$data['transaction'] = $this->url->link('saccount/transaction&market_id='.$this->session->data['session_market_id'], '', 'SSL');
		$data['emails'] = $this->url->link('saccount/email&market_id='.$this->session->data['session_market_id'], '', 'SSL');
		   
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/product/seller_right.tpl')) {
			return $this->load->view($this->config->get('config_template') . '/template/product/seller_right.tpl', $data);
		} else {
			return $this->load->view('default/template/product/seller_right.tpl', $data);
		}	   
	}
}
?>