<?php 
class ControllerProductSeller extends Controller {  
	public function index() { 
	
		/*echo $_GET['market_id']. "Testing";
		exit;*/

		//$this->language->load('product/seller');
		
		$this->load->model('catalog/category');

		$this->load->model('catalog/seller');
		
		$this->load->model('catalog/product');
		
		$this->load->model('tool/image');

        if ($this->request->server['HTTPS']) {
			$server = $this->config->get('config_ssl');
		} else {
			$server = $this->config->get('config_url');
		}		
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'p.sort_order';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		
		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else { 
			$page = 1;
		}	

		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_product_limit');
		}

		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home'),
       		'separator' => false
   		);	

		if (isset($this->request->get['seller_id'])) {
		    $seller_id=$this->request->get['seller_id'];
		} else {
			$seller_id=0;
		}	

        if($this->request->get['seller_id']==$this->seller->getId()){
			$data['same_id']=1;
		} else {
			$data['same_id']=0;
		}	

        if (isset($this->request->get['success']) && $this->request->get['success'] == '1') {
			$data['success_alert'] = true;
		} else {
			$data['success_alert'] = false;
		}		
		
		$seller_info = $this->model_catalog_seller->getSeller($seller_id);		
		
		/*print_r($seller_info);
		exit;*/
		$data['fund_cat'] = $this->model_catalog_category->getFundCategories();
		$categories_1 = $this->model_catalog_category->getCategories(0);
		foreach ($categories_1 as $category_1) {
			$level_2_data = array();
			$level_2_data_other = array();

			$categories_2 = $this->model_catalog_category->getCategories($category_1['category_id']);

			foreach ($categories_2 as $category_2) {
				$level_3_data = array();

				$categories_3 = $this->model_catalog_category->getCategories($category_2['category_id']);

				foreach ($categories_3 as $category_3) {
					$level_3_data[] = array(
						'name' => $category_3['name'],
						'href' => $this->url->link('product/category', 'path=' . $category_1['category_id'] . '_' . $category_2['category_id'] . '_' . $category_3['category_id'],'SSL')
					);
				}
              if(strtolower($category_2['name'])!= "others"){
				$level_2_data[] = array(
					'name'     => $category_2['name'],
					'children' => $level_3_data,
					'href'     => $this->url->link('product/category', 'path=' . $category_1['category_id'] . '_' . $category_2['category_id'],'SSL')
				);
			  } else
			  {
				 $level_2_data_other[] = array(
					'name'     => $category_2['name'],
					'children' => $level_3_data,
					'href'     => $this->url->link('product/category', 'path=' . $category_1['category_id'] . '_' . $category_2['category_id'],'SSL')
				); 
			  }
			}
			
			if ($category_1['image']) {
				//$data['thumb'] = $this->model_tool_image->resize($category_1['image'], 270, 270);
				$data['thumb'] = HTTPS_SERVER . 'timthumb.php?src='.HTTPS_SERVER . 'image/' . $category_1['image'].'&h=270&w=270';
			} else {
				$data['thumb'] = '';
			}

			$data['categories'][] = array(
				'name'     => $category_1['name'],
				'thumb' => $data['thumb'],
				'children' => $level_2_data,
				'children_other' => $level_2_data_other,
				'href'     => $this->url->link('product/category', 'path=' . $category_1['category_id'],'SSL')
			);
		}
		$seller_market_info = $this->model_catalog_seller->getSellerMarket($seller_id);
		
		$this->document->addStyle('catalog/view/javascript/jquery/magnific/magnific-popup.css');

		// $this->document->addScript('catalog/view/javascript/jquery/datetimepicker/moment.js');
		// $this->document->addScript('catalog/view/javascript/jquery/datetimepicker/bootstrap-datetimepicker.min.js');
		$this->document->addScript('catalog/view/javascript/jquery/magnific/jquery.magnific-popup.min.js');		
		// $this->document->addStyle('catalog/view/javascript/jquery/datetimepicker/bootstrap-datetimepicker.min.css');
		$this->document->addScript('http://code.jquery.com/jquery-1.9.1.js');	
		
		$this->document->addStyle('catalog/view/javascript/jquery/owl-carousel/owl.carousel.css');
		$this->document->addScript('catalog/view/javascript/jquery/owl-carousel/owl.carousel.min.js');
		$this->document->addStyle('catalog/view/javascript/jquery/prettyPhoto/prettyPhoto.css');
		$this->document->addScript('catalog/view/javascript/jquery/prettyPhoto/jquery.prettyPhoto.js');

		if ($seller_info) {

			
			if ($this->request->server['REQUEST_METHOD'] == 'POST') {
				$emails = explode(',',$this->request->post['emails']);					
				$message = $this->request->post['message'];
				$message .= $this->request->post['url'];
				$mail = new Mail();
				$mail->protocol = $this->config->get('config_mail_protocol');
				$mail->parameter = $this->config->get('config_mail_parameter');
				$mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
				$mail->smtp_username = $this->config->get('config_mail_smtp_username');
				$mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
				$mail->smtp_port = $this->config->get('config_mail_smtp_port');
				$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');
				$mail->setFrom($seller_info['email']);
				$mail->setSender($seller_info['firstname'].' '.$seller_info['lastname']);
				$mail->setSubject(html_entity_decode($this->request->post['subject'], ENT_QUOTES, 'UTF-8'));
				$mail->setText($message);
				foreach($emails as $email){
					$mail->setTo($email);
					$mail->send();
				}
			}
			
	  		$this->document->setTitle($seller_info['firstname']);

			$data['heading_title'] = $seller_info['firstname'];
			$data['market_id'] = $_GET['market_id'];
			$data['folder_name'] = $seller_info['foldername'];
			$data['about_us_seller'] = html_entity_decode($seller_info['about_us'], ENT_QUOTES, 'UTF-8');
			
			$data['market_name'] = isset($seller_market_info['market_name'])?$seller_market_info['market_name']:'';
			$data['font_family'] =  isset($seller_market_info['font_family'])?$seller_market_info['font_family']:'';
			$data['font_size'] =  isset($seller_market_info['font_size'])?$seller_market_info['font_size']:'';
			$data['font_style'] =  isset($seller_market_info['font_style'])?$seller_market_info['font_style']:'';
			$data['font_color'] =  isset($seller_market_info['font_color'])?$seller_market_info['font_color']:'';
			$data['market_place_background'] =  isset($seller_market_info['market_place_background'])?$seller_market_info['market_place_background']:'';
			$data['market_layout'] =  isset($seller_market_info['market_layout'])?$seller_market_info['market_layout']:'';
			
			$data['text_refine'] = $this->language->get('text_refine');
			$data['text_empty'] = $this->language->get('text_empty');			
			$data['text_quantity'] = $this->language->get('text_quantity');
			$data['text_manufacturer'] = $this->language->get('text_manufacturer');
			$data['text_model'] = $this->language->get('text_model');
			$data['text_price'] = $this->language->get('text_price');
			$data['text_tax'] = $this->language->get('text_tax');
			$data['text_points'] = $this->language->get('text_points');
			$data['text_compare'] = sprintf($this->language->get('text_compare'), (isset($this->session->data['compare']) ? count($this->session->data['compare']) : 0));
			$data['text_display'] = $this->language->get('text_display');
			$data['text_list'] = $this->language->get('text_list');
			$data['text_grid'] = $this->language->get('text_grid');
			$data['text_sort'] = $this->language->get('text_sort');
			$data['text_limit'] = $this->language->get('text_limit');
					
			$data['button_cart'] = $this->language->get('button_cart');
			$data['button_wishlist'] = $this->language->get('button_wishlist');
			$data['button_compare'] = $this->language->get('button_compare');
			$data['button_continue'] = $this->language->get('button_continue');
			
			//$data['button_list'] = $this->language->get('button_list');
			//$data['button_grid'] = $this->language->get('button_grid');
			$data['logged'] = $this->seller->isLogged();
			$data['seller_id']= $seller_id;
			$data['seller_group_id']= $_GET['market_id'];

			//if($seller_info['seller_group_id'] == 2){ $_GET['market_id']
			if($_GET['market_id'] == 2){ 
				// i.e. fund raiser type, then video/photo section to be added.
				$setting = array( 
					'seller_id' => $seller_id, 
					'seller_info' => $seller_info
				);
				$data['funding_details'] = $this->load->controller('module/funding',$setting);
				$data['funding_reviews'] = $this->load->controller('module/freviews',$setting);
				$data['share_link']=$this->url->link('product/seller', 'seller_id=' . $seller_id,'SSL');
				//$share_count=file_get_contents("https://api.facebook.com/method/links.getStats?urls=".$data['share_link']."&format=json");
				//$s_cnt=json_decode($share_count);
				//echo "<pre>"; print_r($s_cnt); echo "</pre>";
				//$data['share_count']= ($s_cnt[0]->share_count==0)?$s_cnt[0]->share_count.' share':$s_cnt[0]->share_count.' shares';
				$data['share_count']= 5;
			} else {
				$data['funding_details'] = '';
				$data['funding_reviews'] = '';
			}
			
			$data['add_item']='';
			
			if (is_file(DIR_IMAGE . $this->config->get('config_logo'))) {
				$data['logo'] = $server . 'image/' . $this->config->get('config_logo');
			} else {
				$data['logo'] = '';
			}
		
			$data['front_url']=$server;
			
			$this->load->model('tool/image');		
			
			if (!empty($seller_info) && $seller_info['image'] && file_exists(DIR_IMAGE . $seller_info['image'])) {
				$data['thumb'] = $this->model_tool_image->resize($seller_info['image'], 275, 268);
				$data['image'] = $seller_info['image'];
			} else {
				$data['thumb'] = $this->model_tool_image->resize('no_image.jpg', 275, 268);
				$data['image'] = 'no_image.jpg';
			}

			if (!empty($seller_market_info) && $seller_market_info['market_place_billboard'] && file_exists(DIR_IMAGE . $seller_market_info['market_place_billboard'])) {
				$data['billthumb'] = $this->model_tool_image->resize($seller_market_info['market_place_billboard'], 880, 280);
				$data['billimage'] = $seller_market_info['market_place_billboard'];
			} else {
				$data['billthumb'] = $this->model_tool_image->resize('default-user-bg.jpg', 880, 280);
				$data['billimage'] = 'default-user-bg.jpg';
			}

			$data['name'] = html_entity_decode($seller_info['name'], ENT_QUOTES, 'UTF-8');

			if ($seller_info['aboutus']) {
				$data['aboutus'] = html_entity_decode($seller_info['aboutus'], ENT_QUOTES, 'UTF-8');
			}else{
				$data['aboutus'] = "";
			}

			$data['compare'] = $this->url->link('product/compare');
			
			$url = '';
			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}	

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}	
			
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}

			$data['sellers'] = array();
			
			$results = $this->model_catalog_seller->getseller($seller_id);
			
			$data['sellereview'] = $this->model_catalog_seller->getSellerReview($seller_id);
			$data['sellerating'] = (int)$this->model_catalog_seller->getSellerRating($seller_id);
			
			$data['products'] = array();
			
			$data1 = array(
				'filter_seller_id' => $seller_id, 
				'sort'               => $sort,
				'order'              => $order,
				'start'              => ($page - 1) * $limit,
				'limit'              => $limit
			);

			$product_total = $this->model_catalog_seller->getTotalProducts($data1,$seller_id); 
			$data['product_total']=$product_total;
			
			$results = $this->model_catalog_seller->getsellerproductsnew($data1,$seller_id);
			
			foreach ($results as $result) {	
				if ($result['image']) {
					$image = $this->model_tool_image->resize($result['image'], $this->config->get('config_image_product_width'), $this->config->get('config_image_product_height'));
				} else {
					$image = false;
				}
				
				if (($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) {
					$price = $this->currency->format($this->tax->calculate($result['price'], $result['tax_class_id'], $this->config->get('config_tax')));
				} else {
					$price = false;
				}
				
				if ((float)$result['special']) {
					$special = $this->currency->format($this->tax->calculate($result['special'], $result['tax_class_id'], $this->config->get('config_tax')));
				} else {
					$special = false;
				}	
				
				if ($this->config->get('config_tax')) {
					$tax = $this->currency->format((float)$result['special'] ? $result['special'] : $result['price']);
				} else {
					$tax = false;
				}				
				
				if ($this->config->get('config_review_status')) {
					$rating = (int)$result['rating'];
				} else {
					$rating = false;
				}

				$data['products'][] = array(
					'product_id'  => $result['product_id'],
					'thumb'       => $image,
					'name'        => $result['name'],
					'description' => utf8_substr(strip_tags(html_entity_decode($result['description'], ENT_QUOTES, 'UTF-8')), 0, 100) . '..',
					'price'       => $price,
					'quantity'    =>$result['quantity'],
					'special'     => $special,
					'tax'         => $tax,
					'rating'      => $result['rating'],
					'reviews'     => sprintf($this->language->get('text_reviews'), (int)$result['reviews']),
					'href'        => $this->url->link('product/product', 'product_id=' . $result['product_id'],'SSL')
				);
			}
			
			$url = '';
	
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}

			$data['sorts'] = array();
			
			$data['sorts'][] = array(
				'text'  => "Latest",
				'value' => 'p.sort_order-ASC',
				'href'  => $this->url->link('product/seller','seller_id=' . $this->request->get['seller_id'] .'&sort=p.sort_order&order=ASC' . $url,'SSL')
			);
			
			
			/*$data['sorts'][] = array(
				'text'  => $this->language->get('text_default'),
				'value' => 'p.sort_order-ASC',
				'href'  => $this->url->link('product/seller','seller_id=' . $this->request->get['seller_id'] .'&sort=p.sort_order&order=ASC' . $url)
			);
			
			$data['sorts'][] = array(
				'text'  => $this->language->get('text_name_asc'),
				'value' => 'pd.name-ASC',
				'href'  => $this->url->link('product/seller','seller_id=' . $this->request->get['seller_id'] .'&sort=pd.name&order=ASC' . $url)
			);

			$data['sorts'][] = array(
				'text'  => $this->language->get('text_name_desc'),
				'value' => 'pd.name-DESC',
				'href'  => $this->url->link('product/seller','seller_id=' . $this->request->get['seller_id'] .'&sort=pd.name&order=DESC' . $url)
			);*/

			$data['sorts'][] = array(
				'text'  => $this->language->get('text_price_asc'),
				'value' => 'p.price-ASC',
				'href'  => $this->url->link('product/seller','seller_id=' . $this->request->get['seller_id'] .'&sort=p.price&order=ASC' . $url,'SSL')
			); 

			$data['sorts'][] = array(
				'text'  => $this->language->get('text_price_desc'),
				'value' => 'p.price-DESC',
				'href'  => $this->url->link('product/seller','seller_id=' . $this->request->get['seller_id'] .'&sort=p.price&order=DESC' . $url,'SSL')
			); 
			
			/*if ($this->config->get('config_review_status')) {
				$data['sorts'][] = array(
					'text'  => $this->language->get('text_rating_desc'),
					'value' => 'rating-DESC',
					'href'  => $this->url->link('product/seller','seller_id=' . $this->request->get['seller_id'] .'&sort=rating&order=DESC' . $url)
				); 
				
				$data['sorts'][] = array(
					'text'  => $this->language->get('text_rating_asc'),
					'value' => 'rating-ASC',
					'href'  => $this->url->link('product/seller','seller_id=' . $this->request->get['seller_id'] .'&sort=rating&order=ASC' . $url)
				);
			}
			
			$data['sorts'][] = array(
				'text'  => $this->language->get('text_model_asc'),
				'value' => 'p.model-ASC',
				'href'  => $this->url->link('product/seller','seller_id=' . $this->request->get['seller_id'] .'&sort=p.model&order=ASC' . $url)
			);

			$data['sorts'][] = array(
				'text'  => $this->language->get('text_model_desc'),
				'value' => 'p.model-DESC',
				'href'  => $this->url->link('product/seller','seller_id=' . $this->request->get['seller_id'] .'&sort=p.model&order=DESC' . $url)
			);*/
			
			$url = '';
	
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}	

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
			
			$data['limits'] = array();
			
			$data['limits'][] = array(
				'text'  => $this->config->get('config_catalog_limit'),
				'value' => $this->config->get('config_catalog_limit'),
				'href'  => $this->url->link('product/seller', 'seller_id=' . $this->request->get['seller_id'] . $url . '&limit=' . $this->config->get('config_catalog_limit'),'SSL')
			);
						
			$data['limits'][] = array(
				'text'  => 25,
				'value' => 25,
				'href'  => $this->url->link('product/seller','seller_id=' . $this->request->get['seller_id'] . $url . '&limit=25','SSL')
			);
			
			$data['limits'][] = array(
				'text'  => 50,
				'value' => 50,
				'href'  => $this->url->link('product/seller','seller_id=' . $this->request->get['seller_id'] .$url . '&limit=50','SSL')
			);

			$data['limits'][] = array(
				'text'  => 75,
				'value' => 75,
				'href'  => $this->url->link('product/seller','seller_id=' . $this->request->get['seller_id'] .$url . '&limit=75','SSL')
			);
			
			$data['limits'][] = array(
				'text'  => 100,
				'value' => 100,
				'href'  => $this->url->link('product/seller','seller_id=' . $this->request->get['seller_id'] .$url . '&limit=100' ,'SSL')
			);

			$url = '';
	
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}	

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
	
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}

			$pagination = new Pagination();
			$pagination->total = $product_total;
			$pagination->page = $page;
			$pagination->limit = $limit;
			$pagination->text = $this->language->get('text_pagination');
			$pagination->url = $this->url->link('product/seller','seller_id=' . $this->request->get['seller_id'] .$url . '&page={page}','SSL');
		
			$data['pagination'] = $pagination->render();
		
			$data['results'] = sprintf($this->language->get('text_pagination'), ($product_total) ? (($page - 1) * $limit) + 1 : 0, ((($page - 1) * $limit) > ($product_total - $limit)) ? $product_total : ((($page - 1) * $limit) + $limit), $product_total, ceil($product_total / $limit));

			$data['sort'] = $sort;
			$data['order'] = $order;
			$data['limit'] = $limit;
		
		    if($_GET['market_id'] == 2){
				$data['continue'] = $this->url->link('saccount/extension/insert','','SSL');
			}elseif($_GET['market_id'] == 3){
				$data['continue'] = $this->url->link('saccount/extension/addproduct','','SSL');
			}else{
				$data['continue'] = $this->url->link('saccount/extension/insert'.'','SSL');
			}
			

			$data['column_left'] = $this->load->controller('common/column_left');
			$data['column_right'] = $this->load->controller('common/column_right');
			$data['content_top'] = $this->load->controller('common/content_top');
			$data['content_bottom'] = $this->load->controller('common/content_bottom');
			$data['footer'] = $this->load->controller('common/footer');
			$data['header'] = $this->load->controller('common/header');
			$data['seller_right'] = $this->load->controller('product/seller_right');
			$data['seller_add_item'] = $this->load->controller('product/seller_add_item');
			$data['seller_profile'] = $this->load->controller('product/seller_profile');
			$data['seller_billboard'] = $this->load->controller('product/seller_billboard');
			$data['seller_marketplace'] = $this->load->controller('product/seller_marketplace');
			$data['seller_socialshare'] = $this->load->controller('product/seller_socialshare');
			
			if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/product/seller.tpl')) {
				$this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/product/seller.tpl', $data));
			} else {
				$this->response->setOutput($this->load->view('default/template/product/seller.tpl', $data));
			}
    	} else {
			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}	

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}

			$data['breadcrumbs'][] = array(
				'text'      => $this->language->get('text_error'),
				'href'      => $this->url->link('product/seller', $url),
				'separator' => $this->language->get('text_separator')
			);

			$this->document->setTitle($this->language->get('text_error'));

      		$data['heading_title'] = $this->language->get('text_error');

      		$data['text_error'] = $this->language->get('text_error');

      		$data['button_continue'] = $this->language->get('button_continue');

      		$data['continue'] = $this->url->link('common/home','','SSL');
      		$data['market_id'] = $_GET['market_id'];
			$data['column_left'] = $this->load->controller('common/column_left');
			$data['column_right'] = $this->load->controller('common/column_right');
			$data['content_top'] = $this->load->controller('common/content_top');
			$data['content_bottom'] = $this->load->controller('common/content_bottom');
			$data['footer'] = $this->load->controller('common/footer');
			$data['header'] = $this->load->controller('common/header');
			$data['seller_right'] = $this->load->controller('product/seller_right');
			$data['seller_add_item'] = $this->load->controller('product/seller_add_item');
			$data['seller_profile'] = $this->load->controller('product/seller_profile');
			$data['seller_billboard'] = $this->load->controller('product/seller_billboard');
			$data['seller_marketplace'] = $this->load->controller('product/seller_marketplace');
			$data['seller_socialshare'] = $this->load->controller('product/seller_socialshare');

			if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/error/not_found.tpl')) {
				//$this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/error/not_found.tpl', $data));
			} else {
				//$this->response->setOutput($this->load->view('default/template/error/not_found.tpl', $data));
			}
		}
  	}
	
	public function update_market(){
		$this->load->model('catalog/seller');
		$val=$this->model_catalog_seller->update_market($this->request->post);
		if($val){
			echo json_encode("success");
		}else{
			echo json_encode("faliure");
		}
	}
	
	public function update_profile(){
		$this->load->model('catalog/seller');
		$val=$this->model_catalog_seller->update_profile($this->request->post);
		if($val){
			echo json_encode("success");
		}else{
			echo json_encode("faliure");
		}
	}
	
	public function update_billboard(){
		$this->load->model('catalog/seller');
		$val=$this->model_catalog_seller->update_billboard($this->request->post);
		if($val){
			echo json_encode("success");
		}else{
			echo json_encode("faliure");
		}
	}
	
	public function review() {
		
		$this->load->model('catalog/review');

		$data['text_no_reviews'] = 'There are no reviews for this fund raiser.';

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$data['reviews'] = array();

		$review_total = $this->model_catalog_review->getTotalReviewsBySellerId($this->request->get['seller_id']);

		$results = $this->model_catalog_review->getReviewsBySellerId($this->request->get['seller_id'], ($page - 1) * 5, 5);

		foreach ($results as $result) {
			$data['reviews'][] = array(
				'author'     => $result['author'],
				'text'       => nl2br($result['text']),
				'total'       => $this->currency->format($result['total']),
				'rating'     => (int)$result['rating'],
				'date_added' => date($this->language->get('date_format_short'), strtotime($result['date_added']))
			);
		}

		$pagination = new Pagination();
		$pagination->total = $review_total;
		$pagination->page = $page;
		$pagination->limit = 5;
		$pagination->url = $this->url->link('product/seller/review', 'seller_id=' . $this->request->get['seller_id'] . '&page={page}','SSL');

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($review_total) ? (($page - 1) * 5) + 1 : 0, ((($page - 1) * 5) > ($review_total - 5)) ? $review_total : ((($page - 1) * 5) + 5), $review_total, ceil($review_total / 5));

		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/product/freview.tpl')) {
			//$this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/product/freview.tpl', $data));
		} else {
			//$this->response->setOutput($this->load->view('default/template/product/freview.tpl', $data));
		}
	}

	public function write() {
		$this->load->language('product/product');

		$json = array();

		if ($this->request->server['REQUEST_METHOD'] == 'POST') {
			if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 25)) {
				$json['error'] = $this->language->get('error_name');
			}

			if ((utf8_strlen($this->request->post['text']) < 25) || (utf8_strlen($this->request->post['text']) > 1000)) {
				$json['error'] = $this->language->get('error_text');
			}

			/* if (empty($this->request->post['rating']) || $this->request->post['rating'] < 0 || $this->request->post['rating'] > 5) {
				$json['error'] = $this->language->get('error_rating');
			} */

			// Captcha
			if ($this->config->get($this->config->get('config_captcha') . '_status') && in_array('review', (array)$this->config->get('config_captcha_page'))) {
				$captcha = $this->load->controller('captcha/' . $this->config->get('config_captcha') . '/validate');

				if ($captcha) {
					$json['error'] = $captcha;
				}
			}

			if (!isset($json['error'])) {
				$this->load->model('catalog/review');

				$this->model_catalog_review->addSReview($this->request->get['seller_id'], $this->request->post);

				$json['success'] = 'Thank you for your review. It has been submitted to the webmaster for approval.';
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}
?>