<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
class ControllerSaccountReports extends Controller {
	public function sold() {
		if (!$this->seller->isLogged()) {
	  		$this->session->data['redirect'] = $this->url->link('saccount/extension', '', 'SSL');
	  		$this->response->redirect($this->url->link('common/home', '', 'SSL'));
    	} 
		$this->load->language('saccount/reports');
		$data = array();
		
		$data['breadcrumbs'] = array();

      	$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home')
      	); 

      	$data['breadcrumbs'][] = array(       	
        	'text'      => $this->language->get('text_account'),
			'href'      => $this->url->link('saccount/account', '', 'SSL')
      	);
		
		$data['breadcrumbs'][] = array(       	
        	'text'      => $this->language->get('Sold Items'),
			'href'      => $this->url->link('saccount/reports/sold', '', 'SSL')
      	);
		
		$this->document->setTitle($this->language->get('Sold Items'));
		
		$data['error_warning'] = '';
		$data['success'] = '';
		$data['heading_title'] = $this->language->get('heading_title');
		$data['heading_title'] = $this->language->get('heading_title');
		
		if($this->seller->isLogged()){
			$seller_id = $this->seller->getId();	
		}else{
		    $seller_id = 0;
		}
		   
		$data['same_id'] = 1;
		
		$data['seller_id'] = $seller_id;
		
		$data['text_enabled'] = $this->language->get('text_enabled');		
		$data['text_disabled'] = $this->language->get('text_disabled');		
		$data['text_no_results'] = $this->language->get('text_no_results');		
		$data['text_image_manager'] = $this->language->get('text_image_manager');
		$data['text_confirm'] = $this->language->get('text_confirm');		
		$data['text_list'] = $this->language->get('text_list');		
		$data['column_name'] = $this->language->get('column_name');
		$data['column_date_added'] = $this->language->get('column_date_added');
		$data['column_status'] = $this->language->get('column_status');		
		$data['column_action'] = $this->language->get('column_action');		
		$data['column_image'] = $this->language->get('column_image');		
		$data['column_name'] = $this->language->get('column_name');		
		$data['column_model'] = $this->language->get('column_model');		
		$data['column_price'] = $this->language->get('column_price');		
		$data['column_quantity'] = $this->language->get('column_quantity');		
		$data['button_copy'] = $this->language->get('button_copy');		
		$data['button_insert'] = $this->language->get('button_insert');		
		$data['button_delete'] = $this->language->get('button_delete');		
		$data['button_filter'] = $this->language->get('button_filter');		
		$data['button_edit'] = $this->language->get('button_edit');

		$this->load->model('saccount/reports');$this->load->model('catalog/seller');
		
		if (isset($this->request->get['filter_date_start'])) {
			$filter_date_start = $this->request->get['filter_date_start'];
		} else {
			$filter_date_start = '';
		}

		if (isset($this->request->get['filter_date_end'])) {
			$filter_date_end = $this->request->get['filter_date_end'];
		} else {
			$filter_date_end = '';
		}

		if (isset($this->request->get['filter_order_status_id'])) {
			$filter_order_status_id = $this->request->get['filter_order_status_id'];
		} else {
			$filter_order_status_id = 0;
		}
		
		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		$data['products'] = array();
		$filter_data = array(
			'filter_seller'	     => $seller_id,
			'filter_date_start'	     => '',
			'filter_date_end'	     => '',
			'filter_order_status_id' => 0,
			'start'                  => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                  => $this->config->get('config_limit_admin')
		);
		$product_total = $this->model_saccount_reports->getTotalPurchased($filter_data);
		$results = $this->model_saccount_reports->getPurchased($filter_data);
		
		$data['seller_id']= $this->seller->getId();
		$seller_info = $this->model_catalog_seller->getSeller($data['seller_id']);	
        $data['folder_name'] = $seller_info['foldername'];		
		$this->load->model('tool/image');
		foreach ($results as $result) {
			if ($result['image']) {
				$data['thumb'] = $this->model_tool_image->resize($result['image'], 90, 90);
			} else {
				$data['thumb'] = '';
			}
			if (($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) {
				$data['price'] = $this->currency->format($result['price']);
			} else {
				$data['price'] = false;
			}
			$data['products'][] = array(
				'name'       => $result['name'],
				'thumb'       => $data['thumb'],
				'model'      => $result['model'],
				'quantity'   => $result['quantity'],
				'price'   => $data['price'],
				'total'      => $this->currency->format($result['total'], $this->config->get('config_currency'))
			);
		}
		
		$data['results'] = sprintf($this->language->get('text_pagination'), ($product_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($product_total - $this->config->get('config_limit_admin'))) ? $product_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $product_total, ceil($product_total / $this->config->get('config_limit_admin')));
		
		$url = '';

		if (isset($this->request->get['filter_date_start'])) {
			$url .= '&filter_date_start=' . $this->request->get['filter_date_start'];
		}

		if (isset($this->request->get['filter_date_end'])) {
			$url .= '&filter_date_end=' . $this->request->get['filter_date_end'];
		}

		if (isset($this->request->get['filter_order_status_id'])) {
			$url .= '&filter_order_status_id=' . $this->request->get['filter_order_status_id'];
		}
		
		$pagination = new Pagination();
		$pagination->total = $product_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('saccount/reports/sold', $url . '&page={page}', 'SSL');

		$data['pagination'] = $pagination->render();
		
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
		$data['seller_right'] = $this->load->controller('product/seller_right');
		$data['seller_profile'] = $this->load->controller('product/seller_profile');
		$data['seller_billboard'] = $this->load->controller('product/seller_billboard');
		$data['seller_marketplace'] = $this->load->controller('product/seller_marketplace');
		$data['seller_add_item'] = $this->load->controller('product/seller_add_item');
		
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/saccount/sold.tpl')) {
			$this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/saccount/sold.tpl', $data));
		} else {
			$this->response->setOutput($this->load->view('default/template/saccount/sold.tpl', $data));
		}
	} 		
}
?>