<?php
// Heading 
$_['heading_title']      = 'Sold Items';

// Column
$_['column_date_added']  = 'Date Added';
$_['column_description'] = 'Description';
$_['column_points']      = 'Points';
$_['column_image']      = 'Image';
$_['column_name']      = 'Name';
$_['column_model']      = 'Model';
$_['column_price']      = 'Price';
$_['column_quantity']      = 'Quantity';
$_['column_action']      = 'Action';

// Text
$_['text_list']       = 'List';
$_['text_account']       = 'Account';
$_['text_reward']        = 'Reward Points';
$_['text_total']         = 'Your total number of reward points is:';
$_['text_empty']         = 'You do not have any reward points!';
?>